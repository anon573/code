import numpy as np
import copy

import matplotlib.pyplot as plt

from math import factorial
import math

from scipy.stats import t

import shap
import time

import operator as op
from functools import reduce

def normpdf(x, mean, sd):
    var = float(sd)**2
    denom = (2*math.pi*var)**.5
    num = math.exp(-(float(x)-float(mean))**2/(2*var))
    return num/denom

class shap_image_explainer:
	def __init__(self):
		pass

	def explain(self, x, nsamples, f, labels):

		def bits2int(x):
			return np.array([sum(1<<i for i, b in enumerate(x[q]) if b) for q in range(x.shape[0])])

		def nCk(n, r):
			r = min(r, n-r)
			numer = reduce(op.mul, range(n, n-r, -1), 1)
			denom = reduce(op.mul, range(1, r+1), 1)
			return numer / denom

		kernel = np.ones(nsamples)
		all_data = []

		M = x.shape[0]

		weights = np.array([((M - 1) / (nCk(M, k) * k * (M - k))) for k in range(1,M)])
		weights = weights / np.sum(weights)
		ones = np.arange(M-1)+1

		# preproccessed 0,1 arrays as bit map and store for later use
		potential_data = np.random.choice([0,1], (nsamples*4, x.shape[0]))
		corresponding_integer = bits2int(potential_data)
		bits_used = set()

		i = 0
		while len(all_data) < nsamples:
			data_row = np.zeros(x.shape[0]) 
			num_one = np.random.choice(ones, p=weights)
			data_row[:num_one] = 1

			np.random.shuffle(data_row)
			all_data.append(data_row)
			i += 1 

		all_data = np.array(all_data)
		# Don't fail silently if we haven't collected enough data
		if all_data.shape[0] != nsamples:
			print ('Not nsamples data collected')

		y = f(all_data)[:,labels]
		ey_values = copy.deepcopy(x) 
		ey_values[:] = 0
		ey_values = np.expand_dims(ey_values, axis=0)
		
		null = f(ey_values)[:,labels]

		y = y - null

		del potential_data
		del bits_used

		return all_data, y, kernel

	def explain_instance(self, image, classifier_fn, hide_color, labels, segmentation, num_samples, model_regressor, mnist=False, batch_size=50):
		# Main image explainer

		if hide_color != 0:
			print ("Only background 0 right now.")
			raise NotImplementedError

		def f(z):
			return classifier_fn(self.mask(z, segmentation, image, hide_color, mnist))

		start_time = time.time()
		X, y, w = self.explain(np.ones(len(np.unique(segmentation))), num_samples, f, labels)
		end_time = time.time() - start_time

		model_regressor.fit(X, y, sample_weight=w, shap=True)
		bays_shap = model_regressor.coef_
		bays_shap = list(bays_shap)

		j = (model_regressor.intercept_,
		sorted(zip(np.arange(len(np.unique(segmentation))), model_regressor.coef_),
			   key=lambda x: np.abs(x[1]), reverse=True),
		model_regressor.model_score)

		samples = model_regressor.draw_samples(10000)
		weights = samples['weights']

		posterior_samples = (abs(weights - model_regressor.coef_))
		p_0 = t.pdf(0, df=model_regressor.deg, loc=0, scale=np.sqrt(model_regressor.s_2))

		# build data format
		r = {
			'ret_exp' : {labels: j[1]},
			# 'data': X,
			# 'weights': w,
			# 'labels': y,
			# 'model': model_regressor,
			'p_0': p_0,
			'posterior_samples': posterior_samples,
			'prediction_score': j[2],
			'time':end_time
		}

		del model_regressor
		del X
		del y
		del w

		return r

	def mask(self, mask, segments, image, hide_color,mnist=False):
		masked_images = []

		for l in range(mask.shape[0]):

			fudged_image = copy.deepcopy(image)
			fudged_image[:] = hide_color

			temp = copy.deepcopy(image)
			zeros = np.where(mask[l] == 0)[0]
			mask_image = np.zeros(segments.shape).astype(bool)
			for z in zeros:
				mask_image[segments == z] = True
			temp[mask_image] = fudged_image[mask_image]
			masked_images.append(temp)
		
		m = np.array(masked_images)
		return m

	def diplay_image(self, segmentation, shap_values, image):
		from matplotlib.colors import LinearSegmentedColormap
		colors = []
		for l in np.linspace(1,0,100):
		    colors.append((245/255,39/255,87/255,l))
		for l in np.linspace(0,1,100):
		    colors.append((24/255,196/255,93/255,l))
		cm = LinearSegmentedColormap.from_list("shap", colors)

		max_val = np.max(shap_values)

		plt.imshow(image, alpha=0.2)
		plt.imshow(self.fill_segmentation(shap_values, segmentation), cmap=cm, vmin=np.min(shap_values), vmax=max_val)
		plt.savefig("test.png")

	def fill_segmentation(self, values, segmentation):
		out = np.zeros(segmentation.shape)
		for i in range(len(values)):
			out[segmentation == i] = values[i]

		return out

"""
	def explain_unc_samp(self, x, nsamples, f, batch_size, model_regressor, label):
		STARTING_SAMPLES = 50
		M = x.shape[0]
		data, y, all_kernel = self.explain(x,STARTING_SAMPLES,f)
		y = y[:, label]

		for i in range(0,nsamples - STARTING_SAMPLES,batch_size):
			potential_data = np.random.randint(0, 2, 1000 * M).reshape((1000, M))

			model_regressor.fit(data, y, sample_weight=all_kernel, shap=True)
			
			_, std = model_regressor.predict(potential_data)
			temp = 50
			std *= temp
			exp = np.exp(std)
			all_exp = np.sum(exp)
			weighst =  exp / all_exp
			lc_masks_indcs = np.random.choice(len(std), p=std, replace=False)

			kernel = np.zeros(batch_size)

			for j, row in enumerate(potential_data[lc_masks_indcs]):
				k = np.count_nonzero(row)

				if k == x.shape[0] or k == 0:
					kernel[j] = 1
				else:	
					kernel[j] = (M - 1) / (nCk(M, k) * k * (M - k))

			new_data = np.array(potential_data[lc_masks_indcs])
			y = np.concatenate((y, f(new_data)[:,label]))
			data = np.vstack((data, new_data))
			all_kernel = np.concatenate((all_kernel, kernel))

			model_regressor.fit(data, y, sample_weight=all_kernel, shap=True)

		ey_values = copy.deepcopy(x)
		ey_values[:] = 0
		ey_values = np.expand_dims(ey_values, axis=0)
		ey = f(ey_values)[:,label]

		y = y - ey

		return data, y, all_kernel



	def explain_instance_uncertainty_sampling(self, image, classifier_fn, hide_color, labels, segmentation, num_samples, model_regressor, mnist=False, batch_size=50):
		# main explainer

		if hide_color != 0:
			print ("Only background 0 right now.")
			raise NotImplementedError

		def f(z):
			return classifier_fn(self.mask(z, segmentation, image, hide_color, mnist))

		start_time = time.time()
		X, y, w = self.explain_unc_samp(np.ones(len(np.unique(segmentation))), num_samples, f, batch_size, model_regressor, labels)
		end_time = time.time() - start_time

		model_regressor.fit(X, y, sample_weight=w, shap=True)
		bays_shap = model_regressor.coef_

		print (bays_shap)

		m = (self.mask(np.ones((1,len(np.unique(segmentation)))), segmentation, image, hide_color, mnist))
		# self.diplay_image(segmentation, bays_shap, image)

		j = (model_regressor.intercept_,
		sorted(zip(np.arange(len(np.unique(segmentation))), model_regressor.coef_),
			   key=lambda x: np.abs(x[1]), reverse=True),
		model_regressor.model_score)

		samples = model_regressor.draw_samples(2000)
		weights = samples['weights']

		posterior_samples = (abs(weights - model_regressor.coef_))
		p_0 = t.pdf(0, df=model_regressor.deg, loc=0, scale=model_regressor.s_2)

		# build data format
		r = {
			'ret_exp' : {labels: j[1]},
			'data': X,
			'weights': w,
			'labels': y,
			'model': model_regressor,
			'p_0': p_0,
			'posterior_samples': posterior_samples,
			'prediction_score': j[2],
			'time':end_time
		}

		return r
"""
