## Feature masking ranking exp 
RESULTS=results-removesweep.txt

MNISTDIR=mnist
MNISTLABEL=4
MNISTIMAGES=50
MNISTSEGS=20
MASKING=.05

echo Fidelity and PE0 Comparison 
echo ================================================== 

# LIME
echo MNIST LIME 
FIGNAME=MNISTLIME
python3 experiment_main.py --rerun --masking_threshold $MASKING --explainer_type image --exp_type RFS --figure_name $FIGNAME --image_base_dir $MNISTDIR --model $MNISTDIR --n_segments $MNISTSEGS --label $MNISTLABEL --n_images $MNISTIMAGES --output_file experiments/mnist-lime-RMSWEEP-test.p 

# SHAP
echo MNIST SHAP 
FIGNAME=MNISTSHAP
python3 experiment_main.py --rerun --masking_threshold $MASKING --exp_type RFS --figure_name $FIGNAME --image_base_dir $MNISTDIR --model $MNISTDIR --n_segments $MNISTSEGS --label $MNISTLABEL --n_images $MNISTIMAGES --output_file experiments/mnist-shap-RMSWEEP-test.p --shap 

echo ================================================== 




