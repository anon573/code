Note: much of this code is modfied from the original LIME package avaliable here https://github.com/marcotcr/lime
