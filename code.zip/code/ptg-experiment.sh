# Params
MNISTDIR=mnist
MNISTLABEL=4
MNISTIMAGES=10
MNISTSEGS=20
STARTINGPERTURBATIONS=200
MODEL=mnist

echo Uncertainty sampling
echo ================================================== 

# LIME

# IMAGENET VGG16 LIME
echo MNIST LIME 
FIGNAME=MNISTLIME
python3 experiment_main.py --rerun --n_perturbations $STARTINGPERTURBATIONS --exp_type CCT --figure_name $FIGNAME --image_base_dir $MNISTDIR --model $MODEL --n_segments $MNISTSEGS --label $MNISTLABEL --n_images $MNISTIMAGES --output_file experiments/mnist-lime-predict-levels-lower.p 

echo ================================================== 




