import os, json
import argparse

from copy import deepcopy

from skimage.segmentation import slic, mark_boundaries

import numpy as np
from matplotlib import pyplot as plt
import matplotlib
import seaborn as sns

import pickle as pkl

from utils import *
import pandas as pd

import lime

import sklearn
from skimage.segmentation import mark_boundaries
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestClassifier

from torchvision import models, transforms
from torch.autograd import Variable
import torch.nn.functional as F
from torchvision import datasets, transforms
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

import time
import prob_lime
from prob_lime import lime_image, lime_tabular
from prob_shap import prob_shap_image
from scipy.stats import pearsonr, norm, sem, t
import math

from mpl_toolkits.axes_grid1 import ImageGrid

import logging
logging.basicConfig(filename='results.log',level=logging.DEBUG)
logging.info("===============")

ORIGINAL_IMAGE, PREPROCESSED_IMAGE, PREPROCESSED_SEGMENTATION = 0,1,2
USING_UNCERTAINTY_SAMPLING, USING_RANDOM_SAMPLING = 0, 1
TOPLABELS = 1
HIDECOLOR = 0

idx2label, cls2label, cls2idx = get_imagenet_class_labels()
np.random.seed(321) 

def get_args():
	ps = argparse.ArgumentParser()
	ps.add_argument('--image_base_dir', type=str, default="./image_data", help="Path to image directory to sample from.  We will sample n_images worth of images from this directory.")
	ps.add_argument('--output_file', type=str, help="Where to store the results of the experiment.")
	ps.add_argument('--n_images', type=int, default=100, help="How many images to sample.")
	ps.add_argument('--n_segments', type=int, default=100, help="How many segments to create.")
	ps.add_argument('--model', type=str, default="vgg16", help="Name of model to explain.")
	ps.add_argument('--n_perturbations', type=int, default=1000, help="Number of perturbations to use during training.")
	ps.add_argument('--batch_size', type=int, default=50, help="Batch size of uncertainty samples to take for every update.")
	ps.add_argument('--exp_type', type=str, help="Experiment type. Options: LOR (log odds), PUC (predictive uncertainty), SAM (get samples of uncertanties). EX (Visualize posterior samples on synthetic data).")
	ps.add_argument('--rerun', action='store_true', help="Whether to rerun experiment or load last save. If True, output_file becomes load file and there is no overwrite.")
	ps.add_argument('--masking_threshold', type=float, default=0.1, help="Threshold to do masking for LOR experiments")
	ps.add_argument('--shap', action='store_true', help='whether to use shap.  otherwise use lime')
	ps.add_argument('--label', type=int, help="Label to use for classification.")
	ps.add_argument('--figure_name', type=str,default="fig", help="Name of figure to store.")
	ps.add_argument('--explainer_type', type=str, default='image', help='explainer to use')

	args = ps.parse_args()

	return args

def generate_lime_exp(model, img, segmentation_map, batch_size, num_samples, rootdir, label=None, verbose_testing=False,iden=None,explainer_type="image",data=None,f_names=None,cat_inds=None,shap=False):
	# Gets explanation for Lime using original method and problime 


	if iden is not None:
		num_samples = [50,100,150,200,250,300,350,400,450,500][iden]

	label = [label]

	if explainer_type == "image":
		uncertainaty_explainer = lime_image.LimeImageExplainer(feature_selection='none')
		random_explainer = lime_image.LimeImageExplainer(feature_selection='none')
		# Generate explanation, segmentation_fn is set to pass through because we have already generated 
		# segmentation maps. batch_predict is a function from utils
		unc_samp_explanation = uncertainaty_explainer.explain_instance(img, 
			                                    classifier_fn=lambda images : batch_predict(images, model, rootdir),
			                                    hide_color=HIDECOLOR, 
			                                    batch_size=batch_size,
			                                    labels=label,
			                                    segmentation_fn=lambda x : segmentation_map,
			                                    num_samples=num_samples,
			                                    top_labels=None,
			                                    model_regressor=BayesianLinearRegression(),
			                                    verbose_testing=verbose_testing) 

		explanation = random_explainer.explain_instance(img,
											     classifier_fn=lambda images : batch_predict(images, model, rootdir),
			                                     hide_color=HIDECOLOR, 
			                                     labels=label,
			                                     top_labels=None,
			                                     segmentation_fn=lambda x : segmentation_map,
				                                 num_samples=num_samples) 
	elif explainer_type == "structured":
		uncertainaty_explainer = lime_tabular.LimeTabularExplainer(data,feature_selection='none',feature_names=f_names,
			                                    categorical_features=cat_inds,
			                                    discretize_continuous=True,
			                                    shap=shap)

		if not shap:
			random_explainer = lime_tabular.LimeTabularExplainer(data,feature_selection='none',feature_names=f_names,
				                                    categorical_features=cat_inds,
				                                    discretize_continuous=True,
				                                    shap=shap)

		else:
			random_explainer = None

		unc_samp_explanation = uncertainaty_explainer.explain_instance(img, 
			                                    predict_fn=lambda images : batch_predict(images, model, rootdir),
			                                    labels=label,
			                                    num_samples=num_samples,
			                                    top_labels=None,
			                                    model_regressor=BayesianLinearRegression(),
			                                    num_features=img.shape[0])

		if not shap:
			explanation = random_explainer.explain_instance(img, 
				                                    predict_fn=lambda images : batch_predict(images, model, rootdir),
				                                    labels=label,
				                                    num_samples=num_samples,
				                                    top_labels=None,
				                                    num_features=img.shape[0])
		else:
			explanation = None
			                                    
	else:
		raise NotImplementedError

	r = {'uncertainty_explanation': unc_samp_explanation, 'baseline_explanation': explanation}
	return r

def generate_shap_exp(model, img, segmentation_map, num_samples, rootdir, label=None, iden=None):
	# Generates probabilistic shap explanations

	# uncertainty_explainer = prob_shap_image.shap_image_explainer()

	if iden is not None:
		num_samples = [50,100,150,200,250,300,350,400,450,500][iden]

	# if explainer_type == "image":
	uncertainty_explainer = prob_shap_image.shap_image_explainer()
	exp = uncertainty_explainer.explain_instance(img,
										   lambda images : batch_predict(images, model, rootdir),
										   HIDECOLOR,
										   label,
										   segmentation_map,
										   num_samples,
										   BayesianLinearRegression(),
										   mnist=(True if rootdir == "mnist" else False))

	r = {'uncertainty_explanation': exp, 'baseline_explanation': None}

	return r

def get_mask_and_image(path_to_image, n_segments):
	# Get mask and image for a single image

	pill_transf = get_pill_transf()
	img = get_image(path_to_image)
	pill_transformed_img = np.array(pill_transf(img))

	segments = slic(pill_transformed_img, n_segments=n_segments, compactness=30, sigma=3)

	return img, pill_transformed_img, segments

def generate_sample_of_masks_and_images(root_dir, n_images, n_segments, indcs=None, mnist_digit=4):
	# Gets data set of masks and images to use for testing explanation methods
	# Returns tuple of origal images, preprocessed versions of images (i.e. compressed for models), and segmentations

	if root_dir == "mnist":
		torch.manual_seed(1)
		test_loader = torch.utils.data.DataLoader(
        datasets.MNIST('../data', train=False, download=True, transform=transforms.Compose([
						transforms.ToTensor(),
						transforms.Normalize((0.1307,), (0.3081,))
						])),batch_size=1, shuffle=True)

		original_image, preprocessed_images, preprocessed_segmentations = [], [], []

		found, i = 0, 0
		for data, target in test_loader:
			sample = np.squeeze(data.numpy().astype('double'),axis=0)
			segments = slic(sample.reshape(28,28,1), n_segments=n_segments, compactness=1, sigma=0).reshape(1,28,28)

			if target != mnist_digit:
				continue

			original_image.append(sample)
			preprocessed_images.append(sample)
			preprocessed_segmentations.append(segments)

			found += 1
			i += 1

			# if found >= n_images:
			# 	break

		return (original_image, preprocessed_images, np.array(preprocessed_segmentations))

	# If not mnist assume imagenet

	# Get all potential images from base dir
	f = []
	for (dirpath, dirnames, filenames) in os.walk(root_dir):
		for fn in filenames:
			if fn != ".DS_Store":
				f.append(os.path.join(dirpath,fn))

	f = np.array(f)

	# Select images
	pill_transf = get_pill_transf()
	if not indcs:
		images = np.random.choice(f, size=n_images)
	else:
		images = f[indcs]

	original_image, preprocessed_images, preprocessed_segmentations = [], [], []

	for i, img in enumerate(images):
		# preprocess images
		img = get_image(img)
		pill_transformed_img = np.array(pill_transf(img))

		# get image segments
		segments = slic(pill_transformed_img, n_segments=n_segments, compactness=30, sigma=3)


		# store everything
		preprocessed_images.append(pill_transformed_img)
		original_image.append(img)
		preprocessed_segmentations.append(segments)

	return (original_image, preprocessed_images, np.array(preprocessed_segmentations))

def generate_samples_structured(samples,base_dir):
	if base_dir == "compas":
		X, y, cols,cat_inds = get_and_preprocess_compas_data()
	else:
		X, y, cols,cat_inds = get_and_preprocess_german()

	from sklearn.preprocessing import StandardScaler
	from sklearn.model_selection import train_test_split

	X = X.values

	xtrain,xtest,ytrain,ytest = train_test_split(X,y,test_size=.2)
	ss = StandardScaler().fit(xtrain)

	xtrain = ss.transform(xtrain)
	xtest = ss.transform(xtest)

	rf = RandomForestClassifier(n_estimators=100).fit(xtrain,ytrain)

	return rf, [np.zeros(X.shape[0]), xtest, np.zeros(X.shape[0])], X, y, cols, cat_inds

def get_delta_class_prob_of_removing_imp_features(model, image,	 mask, explanation, label, rootdir, background=0, shap=False):
	#### Gets the delta of image classifier after removing remove range % of top features per the explanation

	if shap:
		feature_weights = explanation[label]
	else:
		feature_weights = explanation.local_exp[label]
	sorted_feature_weights = sorted(feature_weights, key=lambda x : abs(x[1]))[::-1]

	number_segments = len(sorted_feature_weights)
	background = np.zeros_like(image)
	masked_image = deepcopy(image)

	all_masks = [deepcopy(image)]

	# sample out log likelihoods	
	for i, amt in enumerate(sorted_feature_weights):

		if rootdir == "mnist":
			masked_image[0,:] = np.where(amt[0] == mask, background[0,:], masked_image[0,:])
		else:
			for j in range(3):
				masked_image[:, :, j] = np.where(amt[0] == mask, background[:,:,j], masked_image[:,:,j],)
		
		all_masks.append(deepcopy(masked_image))
	
	bp = batch_predict(all_masks, model, rootdir)[:, label]
	class_prob = bp

	delta_class_prob = class_prob[0] - class_prob
	return delta_class_prob, class_prob

def get_samples_at_uncertanties_experiment(run_args):
	# Get samples from posterior over a range of confidences 

	## This could be broken --- significant changes made since last run, not currently being used in experiments!!
	
	print ("-- Generating posterior draws for image over some range")

	if run_args.path_to_image is None:
		raise NameError("Image must be specified.")

	model, device = get_model(run_args)

	try: 
		original_image, processed_image, segments = get_mask_and_image(run_args.path_to_image, run_args.n_segments)
	except:
		raise NameError("Could not find image {}".format(run_args.path_to_image))

	##
	# Get image prediction
	## 

	image_predictions = batch_predict([processed_image], model)

	img_t = get_input_tensors(original_image)
	logits = model(img_t.to(device))

	probs = F.softmax(logits, dim=1)
	probs5 = probs.topk(5)  
	r = tuple((p,c, idx2label[c]) for p, c in zip(probs5[0][0].detach().cpu().numpy(), probs5[1][0].detach().cpu().numpy()))
	
	print ("{} predictions".format(run_args.model) ,r)

	tl = np.argmax(image_predictions[0])
	uncertainaty_explainer = lime_image.LimeImageExplainer()

	unc_samp_explanation, random_exp, unc_exp, data, labels = uncertainaty_explainer.explain_instance_using_uncertainty(processed_image, 
				                                    classifier_fn=lambda images : batch_predict(images, model),
				                                    top_labels=None, 
				                                    hide_color=HIDECOLOR, 
				                                    batch_size=run_args.batch_size,
				                                    labels=tl,
				                                    model_regressor=BayesianLinearRegression(),
				                                    segmentation_fn=lambda x : segments,
				                                    num_samples=run_args.n_perturbations,
				                                    verbose_testing=False)

	# Get test data and write down distance function being used
	test_data = np.random.randint(0, 2, 10000 * np.unique(segments).shape[0]).reshape((10000, np.unique(segments).shape[0]))
	distance_f = lambda x : sklearn.metrics.pairwise_distances(x, np.ones(np.unique(segments).shape[0]).reshape(1,-1), metric='cosine').ravel()
	
	all_samples, uncertainties = [], []

	rng = [105, 125, 150, 250, 500, 750, 1000]

	# for i in range(data.shape[1] + 2, len(data), 10):
	for i in rng:
		br = BayesianLinearRegression(data[:i], labels[:i, tl], weights=distance_f(data[:i]))
		_, cert = br.predict(test_data, weights=distance_f(test_data))

		uncertainty = np.mean(cert)
		uncertainties.append(uncertainty)

		samples = br.draw_samples(3)
		all_samples.append(samples['weights'])

		print ("Uncertainty",uncertainty)

	top_k = 5

	for i, current_certainty_samples in enumerate(all_samples):
		for j, sample in enumerate(current_certainty_samples):
			
			temp_exp = lime_image.ImageExplanation(processed_image, segments)

			temp_exp.local_exp[tl] = sorted(zip(np.unique(segments), sample), 
				key=lambda x: np.abs(x[1]), reverse=True)

			temp, mask = temp_exp.get_image_and_mask(tl, num_features=top_k, positive_only=False)
			img_boundry = mark_boundaries(temp/255, mask)

			plt.imshow(img_boundry)
			plt.savefig('./results/sampled_images/img-{}-{}.png'.format(round(uncertainties[i], 5), j))

def predictive_uncertainty_experiment(run_args):
	# Get range over the predictive uncertainty thresholds

	print ("-- Generating Posterior Predictive Uncertainties throughout training --")

	model, device = get_model(run_args)
	image_base_dir = run_args.image_base_dir

	# Preprocess set of iamges and masks to consider
	image_preprocessing = generate_sample_of_masks_and_images(image_base_dir, 
															  run_args.n_images, 
															  run_args.n_segments) 

	# Set class
	CLASS_LABEL = run_args.label

	##
	# Main experiment loop
	##

	image_id, num_samples, uncertainty_unc_samp, uncertainty_rand_samp = [], [], [], []
	uncertainty_times_all, random_times_all = [], []


	if run_args.rerun:
		for i in range(run_args.n_images):

			m = ("-- Processing {} of {} images --".format(i + 1, run_args.n_images))
			print (m)
			logging.info(m)

			if run_args.shap:
				# hacking in shap to work with this routine
				uncertainty_explainer = prob_shap_image.shap_image_explainer()
				segments = image_preprocessing[PREPROCESSED_SEGMENTATION][i]

				exp = uncertainty_explainer.explain_instance(image_preprocessing[PREPROCESSED_IMAGE][i],
										   lambda images : batch_predict(images, model, image_base_dir),
										   HIDECOLOR,
										   CLASS_LABEL,
										   segments,
										   run_args.n_perturbations+5000,
										   BayesianLinearRegression(),
										   mnist=image_base_dir)

				print ("unc time", exp["time"])

				unc_samp = uncertainty_explainer.explain_instance_uncertainty_sampling(image_preprocessing[PREPROCESSED_IMAGE][i],
										   lambda images : batch_predict(images, model, image_base_dir),
										   HIDECOLOR,
										   CLASS_LABEL,
										   segments,
										   run_args.n_perturbations,
										   BayesianLinearRegression(),
										   mnist=image_base_dir,
										   batch_size=run_args.batch_size)

				print ("unc time",unc_samp["time"])

				experiment = {
					"random_data":exp["data"],
					"random_labels":exp["labels"],
					"r_time":exp["time"],
					"uncertainty_sampled_data":unc_samp["data"],
					"uncertainty_sampled_labels":unc_samp["labels"],
					"u_time":unc_samp["time"],
					"random_weights":exp["weights"],
					"uncertainty_weights":unc_samp["weights"]
				}

			else:
				uncertainaty_explainer = lime_image.LimeImageExplainer()
				segments = image_preprocessing[PREPROCESSED_SEGMENTATION][i]
				
				experiment = uncertainaty_explainer.explain_instance_using_uncertainty(image_preprocessing[PREPROCESSED_IMAGE][i], 
							                                    classifier_fn=lambda images : batch_predict(images, model, image_base_dir),
							                                    top_labels=None, 
							                                    hide_color=HIDECOLOR, 
							                                    batch_size=run_args.batch_size,
							                                    labels=[CLASS_LABEL],
							                                    segmentation_fn=lambda x : segments,
							                                    num_samples=run_args.n_perturbations,
							                                    verbose_testing=True)

			# Set distance function for fit
			def distance_f(x):
				distances = sklearn.metrics.pairwise_distances(x, np.ones(np.unique(segments).shape[0]).reshape(1,-1), metric='cosine').ravel()
				return uncertainaty_explainer.base.kernel_fn(distances)
			
			random_data = experiment['random_data']
			random_labels = experiment['random_labels']
			uncertainty_sampled_data = experiment['uncertainty_sampled_data']
			uncertainty_sampled_labels = experiment['uncertainty_sampled_labels']
			unc_time = experiment['u_time']
			ran_time = experiment['r_time']

			# for j, cutoff in enumerate(range(30,len(random_data)+1,10)):
			j = 0
			cutoff = 50
			while cutoff <= len(random_data):
			
				if run_args.shap:
					br_unc = BayesianLinearRegression(uncertainty_sampled_data[:cutoff], 
							uncertainty_sampled_labels[:cutoff], weights=experiment["uncertainty_weights"][:cutoff], shap=True)
				else:
					br_unc = BayesianLinearRegression(uncertainty_sampled_data[:cutoff], 
								uncertainty_sampled_labels[:, CLASS_LABEL][:cutoff], weights=distance_f(uncertainty_sampled_data)[:cutoff])


				unc = t.pdf(0, df=br_unc.deg, loc=0, scale=np.sqrt(br_unc.s_2))
				# print (unc)

				if run_args.shap:
					br_rand = BayesianLinearRegression(random_data[:cutoff], 
								random_labels[:cutoff], weights=experiment["random_weights"][:cutoff], shap=True)
				else:
					br_rand = BayesianLinearRegression(random_data[:cutoff], 
								random_labels[:, CLASS_LABEL][:cutoff], weights=distance_f(random_data)[:cutoff])


				rand = t.pdf(0, df=br_rand.deg, loc=0, scale=np.sqrt(br_rand.s_2))

				image_id.append(i)
				num_samples.append(cutoff)
				uncertainty_unc_samp.append(unc)
				uncertainty_rand_samp.append(rand)

				# uncertainty_time = unc_time / len(uncertainty_sampled_data) * cutoff
				# print (j)
				# print(len(unc_time))
				try:
					uncertainty_time = unc_time[j]
				except:
					print (j)
					print (len(unc_time))

				random_time = ran_time / len(random_data) * cutoff

				uncertainty_times_all.append(uncertainty_time)
				random_times_all.append(random_time)

				# speed things up a bit at the end
				j += 1
				if cutoff >= 2000:
					cutoff += 500
				else:
					cutoff += 10
				

		df = pd.DataFrame({"ID":image_id, 
						   "num_samples":num_samples, 
						   "uncertainty_unc_samp":uncertainty_unc_samp,
						   "uncertainty_rand_samp":uncertainty_rand_samp,
						   "uncertainty_time": uncertainty_times_all,
						   "random_time": random_times_all})


		df.to_csv(run_args.output_file)
	else:
		df = pd.read_csv(run_args.output_file)

	# df['uncertainty_unc_samp'] = np.log(df['uncertainty_unc_samp'])
	# df['uncertainty_rand_samp'] = np.log(df['uncertainty_rand_samp'])

	df['random_time'] = np.round(df['random_time'],3)
	df['uncertainty_time'] = np.round(df['uncertainty_time'],3)
	###
	# Set up samples versus uncertainty
	###

	# uncertainty sampling

	unc_samp_bins =  np.linspace(0, np.max(df.num_samples.values), 1000)
	unc_samp_groups = df.groupby(pd.cut(df.num_samples, unc_samp_bins))

	unc_samp_uncertainty_means = unc_samp_groups.uncertainty_unc_samp.mean()
	unc_samp_uncertainty_std = unc_samp_groups.uncertainty_unc_samp.sem() / 2

	unc_samp_pert_means = (unc_samp_bins [:-1] + unc_samp_bins [1:]) / 2
	unc_samp_not_nulls = unc_samp_uncertainty_means.notna()

	rand_samp_uncertainty_means = unc_samp_groups.uncertainty_rand_samp.mean()
	rand_samp_uncertainty_std = unc_samp_groups.uncertainty_rand_samp.sem() / 2

	ran_samp_not_nulls = rand_samp_uncertainty_means.notna()

	plt.rcParams.update({'font.size': 15})


	plt.plot(unc_samp_pert_means[ran_samp_not_nulls], rand_samp_uncertainty_means[ran_samp_not_nulls], label="Random Sampling", color='g')
	plt.fill_between(unc_samp_pert_means[ran_samp_not_nulls], 
					  rand_samp_uncertainty_means[ran_samp_not_nulls]-rand_samp_uncertainty_std[ran_samp_not_nulls], 
					  rand_samp_uncertainty_means[ran_samp_not_nulls]+rand_samp_uncertainty_std[ran_samp_not_nulls], color='g', alpha=.2)

	plt.plot(unc_samp_pert_means[unc_samp_not_nulls], unc_samp_uncertainty_means[unc_samp_not_nulls], label="Uncertainty Sampling", color='r')
	plt.fill_between(unc_samp_pert_means[unc_samp_not_nulls], 
					  unc_samp_uncertainty_means[unc_samp_not_nulls]-unc_samp_uncertainty_std[unc_samp_not_nulls], 
					  unc_samp_uncertainty_means[unc_samp_not_nulls]+unc_samp_uncertainty_std[unc_samp_not_nulls], color='r', alpha=.2)


	plt.xscale('log')
	plt.legend(loc='lower right')
	plt.xlabel('Number of model calls')
	plt.ylabel('PDF($\epsilon$=0)')
	plt.tight_layout()
	plt.savefig('results/{}-numcalls-active.png'.format(run_args.figure_name))

	plt.cla()

	##
	# Now do time
	##

	bins = np.logspace(-3,1,50)
	print (bins)
	# bins2 = np.linspace(11,np.max(df.random_time.values),3)

	# bins = np.concatenate((bins,bins2))

	# unc_samp_bins = np.linspace(0, np.max(df.random_time.values), num=100) 
	unc_samp_bins= bins
	unc_samp_groups = df.groupby(pd.cut(df.uncertainty_time, unc_samp_bins))
	unc_samp_uncertainty_means = unc_samp_groups.uncertainty_unc_samp.mean()
	unc_samp_uncertainty_std = unc_samp_groups.uncertainty_unc_samp.sem() /2

	unc_samp_pert_means = (unc_samp_bins [:-1] + unc_samp_bins [1:]) / 2
	unc_samp_not_nulls = unc_samp_uncertainty_means.notna()

	# rand_samp_bins = np.linspace(0,  np.max(df.random_time.values), num=100) 
	rand_samp_bins = bins
	rand_samp_groups = df.groupby(pd.cut(df.random_time, rand_samp_bins))
	rand_samp_uncertainty_means = rand_samp_groups.uncertainty_rand_samp.mean()
	rand_samp_uncertainty_std = rand_samp_groups.uncertainty_rand_samp.sem() / 2
	rand_samp_pert_means = (rand_samp_bins [:-1] + rand_samp_bins [1:]) / 2

	ran_samp_not_nulls = rand_samp_uncertainty_means.notna()


	plt.rcParams.update({'font.size': 15})

	plt.plot(rand_samp_pert_means[ran_samp_not_nulls], rand_samp_uncertainty_means[ran_samp_not_nulls], label="Random Sampling", color='g')
	plt.fill_between(rand_samp_pert_means[ran_samp_not_nulls], 
					  rand_samp_uncertainty_means[ran_samp_not_nulls]-rand_samp_uncertainty_std[ran_samp_not_nulls], 
					  rand_samp_uncertainty_means[ran_samp_not_nulls]+rand_samp_uncertainty_std[ran_samp_not_nulls], color='g', alpha=.2)

	plt.plot(unc_samp_pert_means[unc_samp_not_nulls], unc_samp_uncertainty_means[unc_samp_not_nulls], label="Uncertainty Sampling", color='r')
	plt.fill_between(unc_samp_pert_means[unc_samp_not_nulls], 
					  unc_samp_uncertainty_means[unc_samp_not_nulls]-unc_samp_uncertainty_std[unc_samp_not_nulls], 
					  unc_samp_uncertainty_means[unc_samp_not_nulls]+unc_samp_uncertainty_std[unc_samp_not_nulls], color='r', alpha=.2)

	# if not run_args.shap:
	# plt.xlim(0, 15)
	# else:
	# 	plt.xlim(0, np.max(rand_samp_pert_means[ran_samp_not_nulls]))
	plt.xscale('log')
	plt.legend(loc='lower right')
	plt.xlabel('Wall clock time (Seconds)')
	plt.ylabel('PDF($\epsilon$=0)')
	plt.tight_layout()
	plt.savefig('results/{}-time-active.png'.format(run_args.figure_name))

def remove_features_experiment_sweep(run_args, var_cal=False):
	# Get feature rankings then iteratively remove them
	model, device = get_model(run_args)
	run = run_args.rerun
	LABEL_TO_EXPLAIN = run_args.label

	if run:
		# Preprocess data
		if run_args.explainer_type == "structured":
			model, image_preprocessing, X,y,cols,cat_inds = generate_samples_structured(run_args.n_images, run_args.image_base_dir)
		else:
			X,y,cols = None,None,None
			image_preprocessing = generate_sample_of_masks_and_images(run_args.image_base_dir, 
																	  run_args.n_images, 
																	  run_args.n_segments,
																	  mnist_digit=LABEL_TO_EXPLAIN) 
			cat_inds = None

		# Get predictions across all data
		image_predictions = batch_predict(image_preprocessing[PREPROCESSED_IMAGE], model, run_args.image_base_dir)

		if run_args.explainer_type == "image":
			arg_preds = np.argsort(image_predictions, axis=1)[:-3][::-1]
		else:
			arg_preds = np.argmax(image_predictions, axis=1)

		##
		# Main experiment loop
		##
		explanations_using_uncertainty, baseline_explanation = [], []
		uncertainty_delta_class_probs, uncertainty_original_class_probs = [], [] 
		baseline_delta_class_prob, baseline_original_delta_class_probs = [], []
		image_reference = []

		all_images, all_masks = [], []

		# fixed experiment parameters
		if var_cal:
			to_enumerate = 2
		else:
			to_enumerate = 10

		for i in range(run_args.n_images):
			for run_index in range(to_enumerate):

				if run_index == 0:
					run_args.n_perturbations = 100
				else: 
					run_args.n_perturbations = 10000

				# Build out list of all image indices
				image_reference.append(i)

				# If this is a variance calibration loop, pass perturbation number from command line
				if var_cal:
					index_to_send = None
				else:
					index_to_send = run_index

				##
				# First get explanations
				##
				if run_index == 0:
					message = "-- Processing {}.{} of {}.{} images --".format(i + 1, run_index+1, len(image_preprocessing[PREPROCESSED_IMAGE]), to_enumerate)
					print (message)
					logging.info(message)

				# shap structured currently handled in bayeslime tabular explainer
				if not run_args.shap or run_args.explainer_type == "structured":
					r = generate_lime_exp(model, 
									  image_preprocessing[PREPROCESSED_IMAGE][i], 
									  image_preprocessing[PREPROCESSED_SEGMENTATION][i],
									  run_args.batch_size,
									  run_args.n_perturbations,
									  run_args.image_base_dir,
									  label=LABEL_TO_EXPLAIN,
									  iden=index_to_send,
									  explainer_type=run_args.explainer_type,
									  data=X,
									  f_names=cols,
									  cat_inds=cat_inds,
									  shap=run_args.shap)
				else:
					r = generate_shap_exp(model,
										  image_preprocessing[PREPROCESSED_IMAGE][i],
										  image_preprocessing[PREPROCESSED_SEGMENTATION][i],
										  run_args.n_perturbations,
										  label=LABEL_TO_EXPLAIN,
										  iden=index_to_send,
										  rootdir=run_args.image_base_dir)

				explanations_using_uncertainty.append(r['uncertainty_explanation'])
				baseline_explanation.append(r['baseline_explanation'])

				##
				# Then get delta class probabilities
				##

				if run_args.explainer_type == "image":
					# Get log likelihood for uncertainty sampling
					delta, original = get_delta_class_prob_of_removing_imp_features(model, 
													image_preprocessing[PREPROCESSED_IMAGE][i], 
													image_preprocessing[PREPROCESSED_SEGMENTATION][i],
													r['uncertainty_explanation']['ret_exp'],
													LABEL_TO_EXPLAIN,
													run_args.image_base_dir,
													shap=run_args.shap)

					uncertainty_delta_class_probs.append(delta)
					uncertainty_original_class_probs.append(original)

					if not run_args.shap:
						delta, original = get_delta_class_prob_of_removing_imp_features(model, 
														image_preprocessing[PREPROCESSED_IMAGE][i], 
														image_preprocessing[PREPROCESSED_SEGMENTATION][i],
														r['baseline_explanation']['ret_exp'],
														LABEL_TO_EXPLAIN,
														run_args.image_base_dir,
														shap=run_args.shap)

						baseline_delta_class_prob.append(delta)
						baseline_original_delta_class_probs.append(original)

		explanations_using_uncertainty = np.array(explanations_using_uncertainty)
		baseline_explanation = np.array(baseline_explanation)
		uncertainty_delta_class_probs = np.array(uncertainty_delta_class_probs)
		baseline_original_delta_class_probs = np.array(baseline_original_delta_class_probs)
		image_reference = np.array(image_reference)

		# Save everything
		logging.info("Writing save to {}".format(run_args.output_file))
		with open(run_args.output_file, "wb") as f:
			pkl.dump({'explanations_using_uncertainty': explanations_using_uncertainty, 
				'baseline_explanation': baseline_explanation,
				'uncertainty_delta_class_probs': uncertainty_delta_class_probs,
				'baseline_original_delta_class_probs': baseline_original_delta_class_probs,
				'image_reference': image_reference,
				'all_images':all_images,
				'all_masks':all_masks}, f)

		# We don't need to do anything more if we are just assessing the uncertainty calibration
		if var_cal:
			exit()

	else:
		pass

	matplotlib.rcParams.update({'font.size': 25})
	fig, ax = plt.subplots(nrows=1, ncols=4, figsize=(25,6))

	q = 0
	with open(run_args.output_file, "rb") as f:
		results = pkl.load(f)


		def convert(arr):
			return np.log(arr / (1-arr))

		explanations_using_uncertainty = results['explanations_using_uncertainty']
		baseline_explanation = results['baseline_explanation']
		uncertainty_delta_class_probs = results['uncertainty_delta_class_probs']
		baseline_original_delta_class_probs = results['baseline_original_delta_class_probs']
		image_reference = results['image_reference']

		min_seg = len(min(uncertainty_delta_class_probs, key=lambda x : len(x)))
		uncertainty_delta_class_probs = np.array([np.resize(arr, min_seg) for arr in uncertainty_delta_class_probs])
		baseline_original_delta_class_probs = np.array([np.resize(arr, min_seg) for arr in baseline_original_delta_class_probs])

		##
		# Get top % most certain 
		masking_threshold = run_args.masking_threshold

		top_log_lik_prob_lime = []
		random_log_lik_lime = []
		random_log_lik_prob_lime = []
		top_fidelity_lime = []
		least_confident_prob_lime = []

		uncertainty_delta_class_probs = uncertainty_delta_class_probs[:, np.ceil(uncertainty_delta_class_probs.shape[1] * masking_threshold).astype(int)] #/ np.max(uncertainty_delta_class_probs, axis=1)
		uncertainty_unc_vals = np.array([exp['p_0'] for exp in explanations_using_uncertainty])

		fidelity_baseline_original_delta_class_probs = baseline_original_delta_class_probs[:, np.ceil(baseline_original_delta_class_probs.shape[1] * masking_threshold).astype(int)] #/ np.max(baseline_original_delta_class_probs, axis=1)
		fidelity_baselined_fidelity_values = np.array([exp['prediction_score'] for exp in baseline_explanation])

		sorted_args = np.argsort(fidelity_baselined_fidelity_values)

		def get_bins(x,y):
			# Bins for drawing trend line
			sorted_args = np.argsort(x)
			sort_x = x[sorted_args]
			sort_y = y[sorted_args]

			x_bin, y_mean, y_std = [], [], []

			bin_nums = 500
			for i in range(0,len(x), bin_nums):
				x_bin.append(np.max(sort_x[i:i+bin_nums]))
				y_mean.append(np.mean(sort_y[i:i+bin_nums]))
				y_std.append(np.std(sort_y[i:i+bin_nums]))

			return np.array(x_bin), np.array(y_mean), np.array(y_std)

		binned_unc_x, mean_unc_y, std_unc_y = get_bins(uncertainty_unc_vals, uncertainty_delta_class_probs)
		matplotlib.rcParams.update({'font.size': 15})

		ax[q+1].set_yticks([])
		ax[q+1].set_ylim(0,1)
		ax[q+1].set_xlabel("PDF($\epsilon$=0)")

		ax[q+1].scatter(uncertainty_unc_vals, uncertainty_delta_class_probs, color='#377eb8',alpha=0.2)

		ax[q+1].plot(binned_unc_x, mean_unc_y, color='#ff7f00')
		ax[q+1].fill_between(binned_unc_x, mean_unc_y-(std_unc_y/2), mean_unc_y+(std_unc_y/2), color='#ff7f00', alpha=0.5)

		pr = (pearsonr(uncertainty_unc_vals, uncertainty_delta_class_probs))
		print ("Unc pearson:", pr)
		logging.info(pr)

		binned_fid_x, binned_fid_y, std_binned_fid_y = get_bins(fidelity_baselined_fidelity_values, fidelity_baseline_original_delta_class_probs)

		if q == 0:
			ax[q].set_ylabel("\u0394 Class Probability")

		if q == 0:
			ax[q].set_yticks([val * .1 for val in range(0,11,2)])
		else:
			ax[q].set_yticks([])
		
		ax[q].set_ylim(0,1)
		ax[q].set_xlabel("Local fidelity (R^2)")
		# plt.ylabel("Adjusted \u0394 Class Probability")
		ax[q].scatter(fidelity_baselined_fidelity_values, fidelity_baseline_original_delta_class_probs,color='#377eb8',alpha=0.2)

		ax[q].plot(binned_fid_x, binned_fid_y,color='#ff7f00')
		ax[q].fill_between(binned_fid_x, binned_fid_y-(std_binned_fid_y/2), binned_fid_y+(std_binned_fid_y/2), color='#ff7f00', alpha=0.5)
		
		if q == 2:
			ax[q].set_xlim(-25,1)

		pr = (pearsonr(fidelity_baselined_fidelity_values, fidelity_baseline_original_delta_class_probs))
		print ("Fid pearson:", pr)
		logging.info(pr)

	ax[0].set_title("LIME",fontsize=25)
	ax[1].set_title("BayesLIME",fontsize=25)
	# ax[2].set_title("SHAP",fontsize=25)
	# ax[3].set_title("BayesSHAP",fontsize=25)

	plt.tight_layout()
	plt.savefig('removal-experiment.png')

def variance_calibration(run_args):
	LABEL = run_args.label

	with open(run_args.output_file, "rb") as f:
		results = pkl.load(f)
		explanations_using_uncertainty = results['explanations_using_uncertainty']
		baseline_explanation = results['baseline_explanation']
		uncertainty_delta_class_probs = results['uncertainty_delta_class_probs']
		baseline_original_delta_class_probs = results['baseline_original_delta_class_probs']
		image_reference = results['image_reference']

	all_considered = []

	# In case for some reason we get images explaining incorrect label, present this
	# without crashing
	num_lost = 0

	considering = (['Original', 'Bayes'] if not run_args.shap else ['Bayes'])

	for baseline_original in considering:
		for unique_image in np.unique(image_reference):

			### ProbLIME explanations --- some issues with naming here because we now have shap explanations
			prob_lime = explanations_using_uncertainty[image_reference==unique_image]
			base_lime = baseline_explanation[image_reference==unique_image]

			base_prob_lime = prob_lime[0]

			if baseline_original == 'Original':
				bootstrap_prob_lime = np.delete(base_lime,0,axis=0)
			else:
				bootstrap_prob_lime = np.delete(prob_lime,0,axis=0)

			def get_array_exp(dic):
				# sort by feature number ordering (currently stored by magnitude of coef.)
				exp = dic[LABEL]
				return np.array([val[1] for val in sorted(exp,key=lambda x : x[0])])

			samples = base_prob_lime['posterior_samples']
			
			try:
				if run_args.shap and run_args.model != "structured":
					mean = get_array_exp(base_prob_lime['ret_exp'])
				else:
					mean = get_array_exp(base_prob_lime['ret_exp'].local_exp)
			except:
				num_lost += 1
				continue

			ci = np.percentile(samples,95,axis=0)
			upper = mean + ci
			lower = mean - ci

			instances_considered = 0
			instances_out_of_ci = 0

			for i, bs in enumerate(bootstrap_prob_lime):

				if run_args.shap and run_args.model != "structured":
					exp = get_array_exp(bs['ret_exp'])
				else:
					exp = get_array_exp(bs['ret_exp'].local_exp)
		
				for q in range(exp.shape[0]):
					if exp[q] > upper[q] or exp[q] < lower[q]:
						instances_out_of_ci += 1
					instances_considered += 1

			new_ci = (instances_out_of_ci / instances_considered)
			all_considered.append(new_ci)

		m1 = ('Calibration {}:'.format(baseline_original))
		m2 = ('Mean:', 1-np.mean(all_considered))
		m4 = ('Num. not with correct label:', num_lost)

		logging.info(m1)
		logging.info(m2)
		logging.info(m4)

		print (m1)
		print (m2)
		print (m4)

def correctness_examples(run_args):
	# Visualize examples of method on 2d output
	np.random.seed(111222)
	plt.style.use('seaborn-white')

	matplotlib.rcParams.update({'font.size': 20})
	# plt.gca().axes.get_yaxis().set_visible(False)

	fig, ax = plt.subplots(nrows=1, ncols=4, figsize=(25,5))
	BLIME = True
	for BLIME in [False,True]:
		for ax_i in range(4):

			def f(x, y, linear=True):
				if linear:
					return x
				else:
					return np.sin(x/2) ** 10 + np.cos(10 + (y * x)/2) * np.cos(x)

			x = np.linspace(-5, 5, 50)
			y = np.linspace(-5, 5, 50)

			X, Y = np.meshgrid(x, y)

			if ax_i in [0,1]:
				linear = True
			else:
				linear = False

			Z = f(X, Y, linear=linear)

			min_z = np.min(Z)
			max_z = np.max(Z)

			Z = (Z-min_z) / (max_z - min_z)

			def f(x, y, linear=True):
				if linear:
					return (x - min_z) / (max_z - min_z)
				else:
					return (np.sin(x/2) ** 10 + np.cos(10 + (y * x)/2) * np.cos(x) - min_z) / (max_z - min_z)

			ax[ax_i].contour(X, Y, Z, 50, cmap='RdGy', alpha=.75)

			a,b = 2.2,0
			point = np.array([a,b])
			# Perturb around region

			def get_data():
				
				if ax_i in [0,2]:
					perturb_size = 25
				else:
					perturb_size = 250

				perturb = np.random.normal(0, 1, size=(perturb_size,2))

				p_points = []
				for p in perturb:
					p_points.append(point + p)
				
				p_points.append(point)
				p_points = np.array(p_points)

				if ax_i in [0,1]:
					linear = True
				else:
					linear = False

				y_s = f(p_points[:,0], p_points[:,1], linear=linear)

				return p_points, y_s

			p_points, y_s = get_data()

			def kernel(origin, perturbs, kernel_width):
				d = []
				for p in perturbs:
					d.append(np.sqrt((origin[0] - p[0])**2) +  (origin[1] - p[1])**2)
				d = np.array(d)

				return np.sqrt(np.exp(-(d ** 2) / kernel_width ** 2))

			if BLIME:
				# Get BR
				weights = kernel(point, p_points, .75)
				br = BayesianLinearRegression(p_points, y_s, weights)
				samples = br.draw_samples(2000, prior=True)

				w = samples['weights']
				biases = samples['biases']

				w_0 = np.percentile((abs(br.coef_[0] - w[:,0])),95)
				w_1 = np.percentile((abs(br.coef_[1] - w[:,1])),95)
				b_percentile = np.percentile((abs(br.intercept_ - biases)),95)

				# print (w_0)
				# print (w_1)
				# print (b)

				upper_wo = br.coef_[0] + w_0
				lower_wo = br.coef_[0] - w_0

				upper_w1 = br.coef_[1] + w_1
				lower_w1 = br.coef_[1] - w_1

				# print (upper_wo)
				# print (lower_wo)

				upper_intercept = br.intercept_ + b_percentile
				lower_intercept = br.intercept_ - b_percentile

				print (upper_intercept)

				# print ("prob 0=",t.pdf(0, df=br.deg, loc=0, scale=np.sqrt(br.s_2)))
				# x = np.array([-5, 5])
				ax[ax_i].plot(x, x * (upper_wo / - upper_w1) + (lower_intercept / -upper_w1) + f(a,b,linear=(True if ax_i in [0,1] else False)) / upper_w1,c="#353531", alpha=1, linewidth=4)
				ax[ax_i].plot(x, x * (lower_wo / - lower_w1) + (upper_intercept / -lower_w1) + f(a,b,linear=(True if ax_i in [0,1] else False)) / lower_w1,c="#353531", alpha=1, linewidth=4)
				# continue

			blime_samples, slopes = [], []
			# Graphing
			if not BLIME:
				samples = {}
				samples['weights'] = np.arange(500)

			for i, s in enumerate(samples['weights']):
				x = np.array([-5, 5])
				
				if BLIME:
					w = s
					c1, c2 = w[0], w[1]
					
				else:
					p_points, y_s = get_data()
					weights = kernel(point, p_points, .75)

					m = Ridge(alpha=1, solver='cholesky').fit(p_points, y_s, sample_weight=weights)

					c1 = m.coef_[0]
					c2 = m.coef_[1]
					intc = m.intercept_

				if BLIME:
					# blime_samples.append(x * (c1 / - c2) + (samples['biases'][i] / -c2) + f(a,b,linear=(True if ax_i in [0,1] else False)) /c2)
					blime_samples.append( x * (c1 / - c2) + (samples['biases'][i] / -c2) + f(a,b,linear=(True if ax_i in [0,1] else False)) /c2 ) 
					# ax[ax_i].plot(x, x * (c1 / - c2) + (samples['biases'][i] / -c2) + f(a,b,linear=(True if ax_i in [0,1] else False)) /c2 , c="#a9e5bb", alpha=0.15)
				else:

					ax[ax_i].plot(x, x * (c1 / - c2) + (intc / -c2) + f(a,b,linear=(True if ax_i in [0,1] else False)) /c2 , c="#30BCED", alpha=0.40)

			if BLIME:
				pass 
				# blime_samples = sorted(blime_samples, key=lambda x: sum(abs(x)))
				# num_down = np.floor(len(blime_samples) * .025).astype(int)

				# ax[ax_i].plot(x, blime_samples[-num_down],c="#a9e5bb", alpha=1,linewidth=5)

				# ax[ax_i].plot(x, blime_samples[num_down],c="#a9e5bb", alpha=1,linewidth=5)

			if ax_i == 0:
				ax[ax_i].set_title("Linear, low samples")
			elif ax_i == 1:
				ax[ax_i].set_title("Linear, high samples")
			elif ax_i == 2:
				ax[ax_i].set_title("Non-linear, low samples")
			else:
				ax[ax_i].set_title("Non-linear, high samples")

			print (a,b)
			ax[ax_i].scatter(a,b, s=35, c='yellow', zorder=2.5)#, c='black', s=10)
			ax[ax_i].set_xlim(-5,5)
			ax[ax_i].set_ylim(-5,5)
			ax[ax_i].set_yticks([])
			ax[ax_i].set_xticks([])

		plt.savefig('region.png')

def adversarial_examples(run_args):
	### Use of uncertainty in adversarial examples setting
	### Currently just set up to handle french bulldog images
	from scipy.stats import ttest_ind
	roots = [
	"french_bulldog",
	"scuba",
	"corn",
	"brocc"
	]

	class_labels = [
		245,
		983,
		998,
		937
	]

	exp_index = 0
	root_dir = "./image_data/" + roots[exp_index]

	n_images = 140
	n_images_to_asses_adv = 50

	n_segments = 5
	samples = 100

	adv_color = 0
	class_label_to_use = class_labels[exp_index] 
	
	model, device = get_model(run_args)

	original_images, processed_images, segmentations = \
		generate_sample_of_masks_and_images(root_dir, n_images, n_segments)

    # get train test split
	held_out = np.array(processed_images)[100:]
	processed_images = processed_images[:100]

	###
	## Generate adversarial data set
	##

	processed_adversarial_images = [] 



	adversarial_segmentations = deepcopy(segmentations)

	for p_img in processed_images:
		adversarial_image = deepcopy(p_img)
		adversarial_image[:,0,0] = adv_color

		processed_adversarial_images.append(adversarial_image)

	processed_images = np.vstack((processed_images, processed_adversarial_images))
	segmentations = np.vstack((segmentations, adversarial_segmentations))

	######

	###
	## Next, set up adversarial classifier
	##

	is_ood_x, is_ood = [], []
	is_ood_test = []
	for j in range(processed_images.shape[0]):

		# Choose image for training set
		img_i = np.random.choice(processed_images.shape[0])
		img = processed_images[img_i]
		seg = segmentations[img_i]

		# select random subset of segments to mask
		to_mask_segs = np.random.choice(np.unique(seg), size=np.random.choice(len(np.unique(seg))))
		ood_img = deepcopy(img)

		# Do the masking
		for k in range(3):
			for tms in to_mask_segs:
				ood_img[:,:,k][seg == tms] = 0

		is_ood_x.append(ood_img)
		is_ood.append(1)
	#######

	##
	# Do ood training
	is_ood_x = np.vstack((is_ood_x, processed_images))
	is_ood = np.concatenate((is_ood, np.zeros(processed_images.shape[0])))
		
	from sklearn.ensemble import RandomForestClassifier
	rf = RandomForestClassifier(n_estimators=5).fit(is_ood_x.reshape(is_ood_x.shape[0], -1), is_ood)

	def rf_predict(x):
		k = x.reshape(x.shape[0], -1)
		return rf.predict(k)

	def f(x):
		flat_x = x.reshape(x.shape[0], -1)

		f_d = np.where(flat_x[:,0] == adv_color, 1, 0)
		other_decisions = np.where(flat_x[:,0] == adv_color, 0, 1)

		f_decisions = np.zeros((x.shape[0], 1000))
		f_decisions[:, class_label_to_use] = f_d
		f_decisions[:, 0] = other_decisions

		return f_decisions 

	# Now build the adversarial classifier
	class adv_class:
		def predict(self, x):
			flat_x = x.reshape(x.shape[0], -1)
			f_decisions = f(x)

			# get function decisions
			phi_decisions = batch_predict(x, model)

			# get array for easy slicing
			is_ood = rf_predict(x).astype(int)
			inds = np.where(is_ood == 1)

			is_ood_arr = np.zeros((x.shape[0], 1000))
			is_ood_arr[inds[0], :] = 1

			result = np.where(is_ood_arr==1, phi_decisions, f_decisions)

			return result

	# Check fidelity
	original_preds = np.argmax(f(held_out), axis=1)
	adversarial_preds = (np.argmax(adv_class().predict(held_out), axis=1))
	print ("-- % Fidelity",np.sum(adversarial_preds == original_preds) / held_out.shape[0])
			
	##
	# Now assess explanations
	#
	
	explainer = lime_image.LimeImageExplainer(feature_selection='none')
	base_95_credible, adv_95_credible, fidelity_adv, fidelity_base = [], [], [], []

	j = 0
	avg_rank = []

	for img, mask in zip(processed_images, segmentations):
			
		if j >= n_images_to_asses_adv:
			break

		base_explanations = explainer.explain_instance(img, 
			                                    classifier_fn=lambda x: batch_predict(x, model),
			                                    hide_color=HIDECOLOR, 
			                                    batch_size=10,
			                                    top_labels=None,
			                                    labels=[class_label_to_use],
			                                    segmentation_fn=lambda x : mask,
			                                    num_samples=samples,
			                                    model_regressor=BayesianLinearRegression(),
			                                    verbose_testing=False)

		adversarial_explanations = explainer.explain_instance(img, 
			                                    classifier_fn=adv_class().predict,
			                                    hide_color=HIDECOLOR, 
			                                    batch_size=10,
			                                    top_labels=None,
			                                    labels=[class_label_to_use],
			                                    segmentation_fn=lambda x : mask,
			                                    num_samples=samples,
			                                    model_regressor=BayesianLinearRegression(),
			                                    verbose_testing=False)

		fid_adv_exp = explainer.explain_instance(img, 
			                                    classifier_fn=adv_class().predict,
			                                    hide_color=HIDECOLOR, 
			                                    batch_size=10,
			                                    top_labels=None,
			                                    labels=[class_label_to_use],
			                                    segmentation_fn=lambda x : mask,
			                                    num_samples=samples,
			                                    verbose_testing=False)

		fid_base_exp = explainer.explain_instance(img, 
			                                    classifier_fn=lambda x: batch_predict(x, model),
			                                    hide_color=HIDECOLOR, 
			                                    batch_size=10,
			                                    top_labels=None,
			                                    labels=[class_label_to_use],
			                                    segmentation_fn=lambda x : mask,
			                                    num_samples=samples,
			                                    verbose_testing=False)  		                         	                                      

		ranks = (adversarial_explanations['ret_exp'].local_exp[class_label_to_use])
		for rn, rnk in enumerate(ranks):
			if rnk[0] == 0:
				avg_rank.append(rn)

		base_samples = base_explanations['p_0']	
		adv_samples = adversarial_explanations['p_0']

		# base_cred = np.percentile(base_samples, .95, axis=0)
		# adv_cred = np.percentile(adv_samples, .95, axis=0)

		base_95_credible.append(np.log(base_samples))
		adv_95_credible.append(np.log(adv_samples))
		fidelity_adv.append(fid_adv_exp['prediction_score'])
		fidelity_base.append(fid_base_exp['prediction_score'])

		
		if (j+1) % 1 == 0:
			print ("-- Completed {} out of {}!".format(j+1, n_images_to_asses_adv))

		j += 1

	name = ["Adversarial Classifier" for _ in range(len(adv_95_credible))] + ["VGG16" for _ in range(len(base_95_credible))]
	all_95_credible = adv_95_credible + base_95_credible

	print (ttest_ind(adv_95_credible, base_95_credible))

	plt.rcParams.update({'font.size': 17})
	df = pd.DataFrame({" ": name, "P(E=0)": all_95_credible})
	sns.boxplot( x=df[" "], y=df["P(E=0)"])

	plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
	plt.tight_layout()
	plt.savefig("prob.png")


	##@### Now using baseline classifier

	plt.cla()

	name = ["Adversarial Classifier" for _ in range(len(fidelity_adv))] + ["VGG16" for _ in range(len(fidelity_base))]
	all_95_credible = fidelity_adv + fidelity_base

	print (ttest_ind(fidelity_adv, fidelity_base))

	plt.rcParams.update({'font.size': 17})
	df = pd.DataFrame({" ": name, "R^2": all_95_credible})
	sns.boxplot( x=df[" "], y=df["R^2"])

	plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
	plt.tight_layout()
	plt.savefig("fid.png")

def generate_residual_error_plots(run_args):
	# Log odds ratio experiment -- get uncertainty estimates then iteratively remove them
	# This is setup to do 

	model, device = get_model(run_args)
	run = run_args.rerun
	matplotlib.rcParams.update({'font.size': 17})
	# French bulldog label
	LABEL_TO_EXPLAIN = 245

	def distance_f(x):
		distances = sklearn.metrics.pairwise_distances(x, np.ones(np.unique(segments).shape[0]).reshape(1,-1), metric=distance_metric).ravel()
		return self.base.kernel_fn(distances)

	if run:

		# Preprocess set of iamges and masks to consider
		image_preprocessing = generate_sample_of_masks_and_images(run_args.image_base_dir, 
																  run_args.n_images, 
																  run_args.n_segments,
																  indcs = list(range(run_args.n_images))) 

		# Get predictions across all images
		image_predictions = batch_predict(image_preprocessing[PREPROCESSED_IMAGE], model)

		##
		# Main experiment loop
		##

		image_reference = []

		for i in range(run_args.n_images):

			# Build out list of all image indices
			image_reference.append(i)

			img_t = get_input_tensors(image_preprocessing[ORIGINAL_IMAGE][i])
			logits = model(img_t.to(device))

			probs = F.softmax(logits, dim=1)
			probs5 = probs.topk(5)  
			r = tuple((p,c, idx2label[c]) for p, c in zip(probs5[0][0].detach().cpu().numpy(), probs5[1][0].detach().cpu().numpy()))
			
			if r[0][1] != LABEL_TO_EXPLAIN: continue

			print ("{} predictions".format(run_args.model) ,r)

			uncertainaty_explainer = lime_image.LimeImageExplainer(feature_selection='none')
			unc_samp_explanation = uncertainaty_explainer.explain_instance(image_preprocessing[PREPROCESSED_IMAGE][i], 
		                                    classifier_fn=lambda images : batch_predict(images, model),
		                                    hide_color=HIDECOLOR, 
		                                    batch_size=run_args.batch_size,
		                                    labels=[LABEL_TO_EXPLAIN],
		                                    segmentation_fn=lambda x : image_preprocessing[PREPROCESSED_SEGMENTATION][i],
		                                    num_samples=run_args.n_perturbations,
		                                    top_labels=None,
		                                    model_regressor=BayesianLinearRegression())

			br_model = unc_samp_explanation['model']
			data = unc_samp_explanation['data']
			labels = unc_samp_explanation['labels']
			weights = unc_samp_explanation['weights']

			y_hat, y_std = br_model.predict(data)
			residual = (y_hat - labels[:, LABEL_TO_EXPLAIN]) 
			
			sns.distplot(residual, hist = False, kde = True,
                 kde_kws = {'linewidth': 3, 'alpha':.5}, hist_kws={'weights':weights})

			rgba_colors = np.zeros((1000,4))
			# for red the first column needs to be one
			rgba_colors[:,2] = 1.0
			# the fourth column needs to be your alphas
			rgba_colors[:, 3] = weights 
			plt.cla()

			w = weights > .5

			plt.scatter(y_hat[w], residual[w], color=rgba_colors[w])
			plt.xlabel("Local Explanation Prediction")
			plt.ylabel("Local Explanation Residual")
			plt.tight_layout()
			plt.savefig('residual_plots/resvyhat-{}.png'.format(i)) 


		plt.xlabel('Error')
		plt.ylabel('Locally weighted density')
		plt.tight_layout()
		plt.savefig('all_residuals.png')

def queries_vs_wall_clock_time(run_args):
	model, device = get_model(run_args)

	image_preprocessing = generate_sample_of_masks_and_images(run_args.image_base_dir, 
																  1, 
																  100) 

	# Get predictions across all images

	times, iters = [], []
	start = time.time()

	for i in range(10000):
		image_predictions = batch_predict(image_preprocessing[PREPROCESSED_IMAGE], model)

		if (i+1) % 10 == 0:
			times.append(time.time() - start)
			iters.append(i)

	matplotlib.rcParams.update({'font.size': 15})
	plt.plot(iters, times)
	plt.xscale('log')
	plt.xlabel("Model queries")
	plt.ylabel("Time (seconds)")
	plt.tight_layout()
	plt.savefig("times.png")

def check_certainty_thresh(run_args):
	model, device = get_model(run_args)
	LABEL_TO_EXPLAIN = run_args.label
	EXTRA = 50

	image_preprocessing = generate_sample_of_masks_and_images(run_args.image_base_dir, 
																  run_args.n_images + EXTRA, 
																  run_args.n_segments) 


	image_predictions = batch_predict(image_preprocessing[PREPROCESSED_IMAGE], model, run_args.image_base_dir)

	data = []
	reccomended_perturbations = []
	all_certs = [1e-2,9e-3,8e-3,7e-3,6e-3,5e-3]
	strings = ["1e-2","9e-3","8e-3","7e-3","6e-3","5e-3"]
	if run_args.rerun:
		for cert in all_certs:
			cur_perturbs = []
			cert = (cert / 1.96) ** 2
			variances = []

			i = 0
			num_completed = 0

			while num_completed < run_args.n_images:
				print ("-- Processing {} of {} images --".format(i + 1,  run_args.n_images))
						
				if run_args.shap:
					uncertainty_explainer = prob_shap_image.shap_image_explainer()
					expl = uncertainty_explainer.explain_instance(image_preprocessing[PREPROCESSED_IMAGE][i],
											   lambda images : batch_predict(images, model, run_args.image_base_dir),
											   HIDECOLOR,
											   LABEL_TO_EXPLAIN,
											   image_preprocessing[PREPROCESSED_SEGMENTATION][i],
											   run_args.n_perturbations,
											   BayesianLinearRegression())
				else:
					explainer = lime_image.LimeImageExplainer(feature_selection='none')
					expl = explainer.explain_instance(image_preprocessing[PREPROCESSED_IMAGE][i], 
					                                    classifier_fn=lambda images : batch_predict(images, model, run_args.image_base_dir),
					                                    hide_color=HIDECOLOR, 
					                                    batch_size=run_args.batch_size,
					                                    labels=[LABEL_TO_EXPLAIN],
					                                    segmentation_fn=lambda x : image_preprocessing[PREPROCESSED_SEGMENTATION][i],
					                                    num_samples=run_args.n_perturbations,
					                                    top_labels=None,
					                                    model_regressor=BayesianLinearRegression(),)

				level = cert
				print ("Desired level {}".format(level))
				num_needed = expl['model'].compute_number_more_needed_for_cert(level)
				print ("Num perturbs needed:", num_needed)


				if num_needed - 5 <= run_args.n_segments:
					print (num_needed)
					print (run_args.n_segments)
					i += 1
					continue

				cur_perturbs.append(num_needed)

				if not run_args.shap:
					val_explainer = lime_image.LimeImageExplainer(feature_selection='none')
					val_expl = val_explainer.explain_instance(image_preprocessing[PREPROCESSED_IMAGE][i], 
					                                    classifier_fn=lambda images : batch_predict(images, model, run_args.image_base_dir),
					                                    hide_color=HIDECOLOR, 
					                                    batch_size=run_args.batch_size,
					                                    labels=[LABEL_TO_EXPLAIN],
					                                    segmentation_fn=lambda x : image_preprocessing[PREPROCESSED_SEGMENTATION][i],
					                                    num_samples=int(num_needed),
					                                    top_labels=None,
					                                    model_regressor=BayesianLinearRegression())
				else:
					uncertainty_explainer = prob_shap_image.shap_image_explainer()
					val_expl = uncertainty_explainer.explain_instance(image_preprocessing[PREPROCESSED_IMAGE][i],
											   lambda images : batch_predict(images, model, run_args.image_base_dir),
											   HIDECOLOR,
											   LABEL_TO_EXPLAIN,
											   image_preprocessing[PREPROCESSED_SEGMENTATION][i],
											   int(num_needed),
											   BayesianLinearRegression())

				var_at_end = np.percentile(val_expl['posterior_samples'],95,axis=0)
				variances.extend(var_at_end.flatten())

				i += 1
				num_completed += 1

			reccomended_perturbations.append(cur_perturbs)

			variances = np.array(variances).flatten()

			if data == []:
				data = [variances]
			else:
				data.append(variances)

		data = np.array(data)


		with open(run_args.output_file, "wb") as f:
			pkl.dump({'data': data,'rec':reccomended_perturbations}, f)

	else:
		pass

	# data = data)

	matplotlib.rcParams.update({'font.size': 25})
	fig, ax = plt.subplots(nrows=1, ncols=3, figsize=(25,6))

	q = 0
	for data_files in ["experiments/mnist-lime-predict-levels.p","experiments/mnist-lime-predict-levels-lower.p"][::-1]:#, "experiments/mnist-lime-predict-levels-3.p"]:

		with open(data_files, "rb") as f:
			r = pkl.load(f)
			data = r['data']


		if q == 0:
			c1 = "#92DCE5"
			c2 = 'b'
			label= "100"
		else:
			c1 = "#FFC107"
			c2 = "r"
			label = "200"


		ax[2].set_ylabel("Estimated Perturbations")
		arr = np.array(r['rec'])
		mean = np.mean(arr,axis=1)
		std = np.std(arr,axis=1)
		ax[2].plot(strings,mean,linewidth=3,label=label,c=c2)
		# ax[2].plot(strings,mean+std,color=c2,linestyle='dashed',linewidth=3)
		# if q == 0:
		# 	ax[2].plot(strings,mean-std,color=c2,linestyle='dashed',linewidth=3)
		# else:
		# 	ax[2].plot(strings,mean-std,color=c2,linestyle='dashed',linewidth=3)
		ax[2].fill_between(strings,mean-std,mean+std,color=c2,alpha=.15)
		ax[2].set_xlabel("Desired $CI_{w}$")
		ax[2].legend(loc='upper left')
		ax[2].ticklabel_format(style='sci', axis='y', scilimits=(0,0))
			# ax[2].fill_between(strings,mean+std,mean-std)

		data = data.transpose()
		matplotlib.rcParams.update({'font.size': 20})
		# fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(10, 6))

		ax[q].boxplot(data, labels=strings, notch=False, showfliers=False ,widths=[.6] * len(all_certs))
		ax[q].ticklabel_format(style='sci', axis='y', scilimits=(0,0))

		print(data.shape)
		medians = np.median(data,axis=0)
		ax[q].plot([i+1 for i in range(len(all_certs))], medians,c="#92DCE5")
		ax[q].scatter([i+1 for i in range(len(all_certs))], all_certs, s=50)

		# plt.yscale('log')
		# axes.get_yaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
		ax[q].ticklabel_format(style='sci', axis='y', scilimits=(0,0))
		# ax.yaxis .set_major_formatter(FormatStrFormatter('%.0f'))
		ax[q].set_xlabel("Desired $CI_{w}$")

		if q == 0:
			ax[q].set_title("100 Initial Perturbations")
		else:
			ax[q].set_title("200 Initial Perturbations")
		
		ax[q].set_ylabel("Observed $CI_{w}$")
		# else:
		# 	ax[q].set_yticks([])
		# axes.grid()
		# axes.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
		q = q + 1

	plt.tight_layout()
	plt.savefig("example.png".format(run_args.figure_name))

def generate_samples(run_args):
	from PIL import Image
	run_args.model = "structured"
	run_args.explainer_type = "structured"
	run = run_args.rerun
	mnist = False
	PLOTPAGE = False
	np.random.seed(6)
	run_args.n_images = 100

	if mnist:
		LABEL_TO_EXPLAIN = 8
		run_args.image_base_dir = "mnist"
	elif run_args.explainer_type == "structured":
		LABEL_TO_EXPLAIN = 0
		run_args.image_base_dir = "compas"
	else:
		# LABEL_TO_EXPLAIN = 239
		LABEL_TO_EXPLAIN = 245
		run_args.image_base_dir = "./image_data/french_bulldog"
		# run_args.image_base_dir = "./data/dog_cat/"

	model, device = get_model(run_args)

	if run_args.explainer_type == "structured":
		model, image_preprocessing, X,y,cols,cat_inds = generate_samples_structured(run_args.n_images)
		print (cols)
	else:
		image_preprocessing = generate_sample_of_masks_and_images(run_args.image_base_dir, 
															  run_args.n_images, 
															  run_args.n_segments,
															  mnist_digit=LABEL_TO_EXPLAIN)
		
	run_args.n_perturbations = 5000
	run_args.n_segments = 20
	TOPFEATURES = 9

	# don't really need to do complex image stuff
	if run_args.explainer_type == "structured":
		IMAGEID = 17

		r = generate_lime_exp(model, 
								image_preprocessing[PREPROCESSED_IMAGE][IMAGEID], 
								image_preprocessing[PREPROCESSED_SEGMENTATION][IMAGEID],
								run_args.batch_size,
								run_args.n_perturbations,
								run_args.image_base_dir,
								label=LABEL_TO_EXPLAIN,
								explainer_type="structured",
								data=X,
								f_names=cols,
								cat_inds=cat_inds)

		explanation = r["uncertainty_explanation"]
		bays_model = r['uncertainty_explanation']['model']
		importances = bays_model.coef_

		pdfs = []
		xranges = []

		sorted_coefs = np.argsort(abs(bays_model.coef_))[::-1][:4]

		for f in sorted_coefs:
			marginal_feature_importance = bays_model.get_marginal_feature_importance_vals(f)

			degrees_of_freedom = marginal_feature_importance['degrees_of_freedom']
			v_ii = marginal_feature_importance['v_ii']
			s_2 = marginal_feature_importance['s_2']

			x_range = np.linspace(t.ppf(0.2, degrees_of_freedom), t.ppf(0.8, degrees_of_freedom), 1e4)
			xranges.extend(x_range)
			# print (importances[f])
			pdfs.append(t.pdf(x_range, degrees_of_freedom, loc=abs(importances[f]), scale=np.sqrt(v_ii * s_2)))

		image = image_preprocessing[PREPROCESSED_IMAGE][IMAGEID]

		import seaborn as sns
		sns.set(style="white", rc={"axes.facecolor": (0, 0, 0, 0)})

		# Create the data

		data = []
		cols_names = []
		# xranges = []
		imports = []
		names = {}
		for j, i in enumerate(sorted_coefs):
			samples = pdfs[j]
			data.extend(samples)
			# xranges.append(x_range)
			cols_names.extend([cols[i]] * len(list(samples)))
			imports.extend([bays_model.coef_[i]] * len(list(samples)))
			names[imports[-1]] = cols[i]

		data = {'data':data, 'Absolute Feature Importance':cols_names, 'ranges':xranges,'importances':imports}

		df = pd.DataFrame(data)
		matplotlib.rcParams.update({'font.size': 15})
		# Initialize the FacetGrid object
		pal = sns.diverging_palette(240, 0, n=9)
		g = sns.FacetGrid(df, row='Absolute Feature Importance', hue='importances', aspect=10, height=1)
		# Draw the densities in a few steps
		
		# g.map(plt.fill_between,'ranges','data',alpha=1)
		# g.map(sns.lineplot, "ranges", 'data',color="w", lw=2)

		maps = {}
		for j, i in enumerate(sorted_coefs):
			g.axes[j,0].set_xlabel(cols[i])
			g.axes[j,0].set_xlim(0,.12)

			# g.axes[j,0].get_lines()[0].set_color("black")

		# g.map(plt.hist, 'data')#,color="w", lw=2, bw=.2)
		# g.map(plt.axhline, y=0, lw=2, clip_on=False)

		# g.map(plt.hist, "tip", bins=np.arange(0, 13), color="c").set_titles("{col_name} diners")

		pallete = sns.diverging_palette(10, 130, n=20,center="light")

		# Define and use a simple function to label the plot in axes coordinates
		def label(x, color, label):
		    ax = plt.gca()
		    label = names[float(label)]

		    ax.text(-.02, .2, label, color="black",
		            ha="right", va="center", transform=ax.transAxes)

		def docolor(x_range, data, j,color,label):
			ax = plt.gca()
			importances = float(label)

			upper = np.max(imports) + .01
			lower = upper * -1

			start = lower
			color = None
			inc = (upper - lower) / 20
			for i in range(0,20):
				start += inc
				if start >= importances:
					color = pallete[i]
					break

			if color is None:
				raise NameError('uh oh')

			print 
			ax.fill_between(x_range,data,color=color)


		g.map(docolor, "ranges", "data", "importances")
		g.map(sns.lineplot,'ranges','data',alpha=1, lw=1.5,color=(1,1,1))
		g.map(label,"Absolute Feature Importance")
		

		# Set the subplots to overlap
		g.fig.subplots_adjust(hspace=-.5)

		# Remove axes details that don't play well with overlap
		g.set_titles("")
		g.set(yticks=[])
		# g.set(xticks=[])

		# g.set(xlabel="Feature Importance!",textsize=15)
		plt.gca().set_xlabel('Absolute Feature Importance', fontsize = 20)
		g.despine(bottom=False, left=False, trim=False)


		plt.savefig('test.png')

		exit()


	def fill_segmentation(values, segmentation, image):
		not_max_segs = np.argsort(abs(values))[:-5]
		values[not_max_segs] = 0

		out = np.zeros(segmentation.shape)
		for i in range(len(values)):
			out[segmentation == i] = values[i]

		return out

	def display_image(segmentation, image, model):
		from matplotlib.colors import LinearSegmentedColormap
		colors = []
		for l in np.linspace(1,0,100):
		    colors.append((245/255,39/255,87/255,l))
		for l in np.linspace(0,1,100):
		    colors.append((24/255,196/255,93/255,l))
		cm = LinearSegmentedColormap.from_list("shap", colors)

		samples = [model.coef_]

		results = []
		for z, feature_importances in enumerate(samples):
			max_val = np.max(feature_importances)
			results.append((fill_segmentation(feature_importances, segmentation, image), cm, -max_val, max_val))

		return results

	def get_all_but_rank_masked(segmentations, rank, image, feature_imps, base_dir):

		fid = np.argsort(abs(feature_imps))[-1 * (1 + rank)]
		out = deepcopy(image)

		for j in range(len(feature_imps)):
			if j != fid:
				if base_dir == "mnist":
					out[segmentations == j] = np.min(image)
				else:
					for i in range(3):
						out[segmentations == j, i] = 255

		return out, fid

	def center_of_mass(segmentations, rank, feature_imps):
		fid = np.argsort(abs(feature_imps))[-1 * (1 + rank)]

		contour = np.where(segmentations == fid)
		
		y = np.mean(contour[0])
		x = np.mean(contour[1])

		return x,y, fid

	for PERTURBATION_AMOUNT in [25,1000]:
		for IMAGEID in range(run_args.n_images):
		
			if not run_args.shap:
				r = generate_lime_exp(model, 
									  image_preprocessing[PREPROCESSED_IMAGE][IMAGEID], 
									  image_preprocessing[PREPROCESSED_SEGMENTATION][IMAGEID],
									  run_args.batch_size,
									  PERTURBATION_AMOUNT,
									  run_args.image_base_dir,
									  label=LABEL_TO_EXPLAIN)
			else:
				r = generate_shap_exp(model, 
									  image_preprocessing[PREPROCESSED_IMAGE][IMAGEID], 
									  image_preprocessing[PREPROCESSED_SEGMENTATION][IMAGEID],
									  PERTURBATION_AMOUNT,
									  run_args.image_base_dir,
									  label=LABEL_TO_EXPLAIN)
		
			for METHOD in ["LIME","BAYESLIME"]:

				### Set up plotting 
				plt.axis('off')
				plt.tick_params(axis='both', left='off', top='off', right='off', bottom='off', labelleft='off', labeltop='off', labelright='off', labelbottom='off')
				fig = plt.figure(figsize=(8., 8.))

				if PLOTPAGE:
					matplotlib.rcParams.update({'font.size': 50})

					if METHOD == "LIME":
						fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(30,10))
						ax = np.array([ax])
					else:
						fig, ax = plt.subplots(nrows=TOPFEATURES + 1, ncols=2, figsize=(50,60))

				else:
					import matplotlib.gridspec as gridspec
					matplotlib.rcParams.update({'font.size': 20})
					canvas = FigureCanvas(fig)
					# fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(10,8))
					# ax3 = plt.subplot(212)
					fig = plt.figure(figsize=(20,8))
					ax1 = plt.subplot2grid((1, 4), (0, 0))
					ax2 = plt.subplot2grid((1, 4), (0, 1))
					ax3 = plt.subplot2grid((1, 4), (0, 2), colspan=2)
					# grid = gridspec.GridSpec(1,3, fig)
				
					ax = np.array([ax1,ax2,ax3])
					# ax = [plt.subplot(grid[i]) for i in range(3)]
				#########
		  
				bays_model = r['uncertainty_explanation']['model']

				importances = bays_model.coef_
				image = image_preprocessing[PREPROCESSED_IMAGE][IMAGEID]
				segments = image_preprocessing[PREPROCESSED_SEGMENTATION][IMAGEID]
				if run_args.image_base_dir == "mnist":
					segments = segments.reshape(28,28)

				images = display_image(segments, image, bays_model)[0]

				if run_args.image_base_dir == "mnist":
					image = np.reshape(image, (28,28))

				if PLOTPAGE:
					if run_args.image_base_dir == "mnist":
						ax[0,0].imshow(mark_boundaries(image, segments), cmap='gray')
						ax[0,1].imshow(mark_boundaries(image, segments), cmap='gray')
					else:
						ax[0,0].imshow(mark_boundaries(image, segments))
						ax[0,1].imshow(Image.fromarray(image).convert("LA"), alpha=.25)

					for i in range((TOPFEATURES + 1 if METHOD == "BAYESLIME" else 1)):
						for j in range(2): 
							if i >= 1 and j >= 1:
								pass
							else:
								ax[i,j].set_xticks([])
							ax[i,j].set_yticks([])

					ax[0,0].set_title("Image")
					ax[0,1].set_title("Explanation")

					if run_args.image_base_dir == "mnist":
						marked_image = mark_boundaries(image, segments)
						marked_zeros = np.expand_dims(mark_boundaries(np.zeros(image.shape), segments)[:,:,0],axis=2)
						rgba_image = np.concatenate((marked_image, marked_zeros),axis=2)

						im = ax[0,1].imshow(images[0].reshape(28,28), cmap=images[1], vmin=images[2], vmax=images[3])
						ax[0,1].imshow(rgba_image)
					else:
						marked_image = mark_boundaries(image, segments)
						marked_zeros = np.expand_dims(mark_boundaries(np.zeros(image.shape), segments)[:,:,0],axis=2)
				
						rgba_image = np.concatenate((marked_image, marked_zeros),axis=2)
						im = ax[0,1].imshow(images[0], cmap=images[1], vmin=images[2], vmax=images[3])
						ax[0,1].imshow(rgba_image)

					cb = fig.colorbar(im, ax=ax[0,1], aspect=40, pad=0.05, orientation='vertical')
					plt.subplots_adjust(hspace=0.1,wspace=0)

					for TP_rank in range(TOPFEATURES):
						x, y, index_of_ranked = center_of_mass(segments, TP_rank, importances)

						if run_args.image_base_dir == "mnist":
							ax[0,1].text(x,y,s=str(TP_rank+1),fontsize=40,c=(1,1,1))
						else:
							ax[0,1].text(x,y,s=str(TP_rank+1),fontsize=40)

						if METHOD == "LIME":
							continue

						all_but_rank_masked, index_of_ranked = get_all_but_rank_masked(segments, TP_rank, image, importances, run_args.image_base_dir)

						marginal_feature_importance = bays_model.get_marginal_feature_importance_vals(index_of_ranked)
						degrees_of_freedom = marginal_feature_importance['degrees_of_freedom']
						v_ii = marginal_feature_importance['v_ii']
						s_2 = marginal_feature_importance['s_2']

						# set explanation
						ax[TP_rank+1,0].set_ylabel("{}".format(TP_rank+1))
						# ax[TP_rank+1,0].imshow(Image.fromarray(all_but_rank_masked))

						if run_args.image_base_dir == "mnist":
							ax[TP_rank+1,0].imshow(all_but_rank_masked, cmap='gray')
							ax[TP_rank+1,1].set_xlim(-2 * np.max(abs(importances)), np.max(abs(importances)) * 2)
						else:
							alpha_matrix = np.ones((224,224,1)) * 255
							# alpha_matrix[all_but_rank_masked[:,:,0] == 255] = 0
							# print (alpha_matrix)

							all_but_rank_masked = np.concatenate((all_but_rank_masked,alpha_matrix),axis=2)
							ax[TP_rank+1,0].imshow(Image.fromarray(all_but_rank_masked.astype(np.uint8)))
							ax[TP_rank+1,0].imshow(Image.fromarray(image),alpha=.2)

							xticks = np.array([val for val in range(0, 11)]) * .1
							xticks = np.concatenate((xticks, -1 * xticks))
							ax[TP_rank+1,1].set_xticks(xticks)

							ax[TP_rank+1,1].set_xlim(-1 * (.05 + np.max(abs(importances))), np.max(abs(importances)) + .05)

						x_range = np.linspace(t.ppf(0.01, degrees_of_freedom), t.ppf(0.99, degrees_of_freedom), 1e4)

						pdf = t.pdf(x_range, degrees_of_freedom, loc=importances[index_of_ranked], scale=np.sqrt(v_ii * s_2))
						pdf = pdf / np.max(pdf)

						ax[TP_rank+1,1].plot(x_range, pdf,linewidth=5.0)
						ax[TP_rank+1,1].grid()

						ax[TP_rank+1,1].arrow(0, .85, np.max(abs(importances)) / 10, 0, length_includes_head=False, head_width=0.1, head_length=0.03, width=.05,color=(24/255,196/255,93/255))
						ax[TP_rank+1,1].arrow(0, .85, -(np.max(abs(importances)) / 10), 0, length_includes_head=False, head_width=0.1, head_length=0.03, width=.05,color=(245/255,39/255,87/255))

				else:
					if run_args.image_base_dir == "mnist":
						ax[0].imshow(mark_boundaries(image, segments), cmap='gray')
						ax[1].imshow(mark_boundaries(image, segments), cmap='gray')
					else:
						marked_image = mark_boundaries(image, segments)
						marked_zeros = np.expand_dims(mark_boundaries(np.zeros(image.shape), segments)[:,:,0],axis=2)
				
						rgba_image = np.concatenate((marked_image, marked_zeros),axis=2)

						ax[0].imshow(marked_image)
						ax[1].imshow(Image.fromarray((mark_boundaries(image, segments) * 255).astype(np.uint8)).convert("LA"), alpha=.5)

					for i in range(2):
						ax[i].set_xticks([])
						ax[i].set_yticks([])

					if run_args.image_base_dir == "mnist":
						im = ax[1].imshow(images[0].reshape(28,28), cmap=images[1], vmin=images[2], vmax=images[3])
					else:
						im = ax[1].imshow(images[0], cmap=images[1], vmin=images[2], vmax=images[3])
						ax[1].imshow(rgba_image)

					cb = plt.colorbar(im, ax=[ax[0],ax[1]], aspect=20, location='bottom', pad=.05)
					pdfs = []

					color_blind_friendly_colors = ["#D35FB7", "#1E88E5", "#FFC107", "#004D40"]

					for rnk in range(1,TOPFEATURES+1):
						# plot text
						x,y , index_of_ranked = center_of_mass(segments, rnk-1, importances)
						ax[1].text(x,y,s=str(round(rnk,2)),fontsize=20)

						# get distribution
						marginal_feature_importance = bays_model.get_marginal_feature_importance_vals(rnk-1)
						degrees_of_freedom = marginal_feature_importance['degrees_of_freedom']
						v_ii = marginal_feature_importance['v_ii']
						s_2 = marginal_feature_importance['s_2']

						x_range = np.linspace(t.ppf(0.01, degrees_of_freedom), t.ppf(0.99, degrees_of_freedom), 1e4)
						pdfs.append(t.pdf(x_range, degrees_of_freedom, loc=importances[index_of_ranked], scale=v_ii * s_2))
					
					pdfs = np.array(pdfs)
					pdfs = pdfs / np.max(pdfs)

					for rnk, pdf in zip(range(1,TOPFEATURES+1), pdfs):
						ax3.plot(x_range, pdf,linewidth=5.0,label="{}".format(rnk), c=color_blind_friendly_colors[rnk-1])

					ax3.set_xlim(-1 * (.05 + np.max(abs(importances))), np.max(abs(importances)) + .05)

					asp = np.abs(np.diff(ax3.get_xlim())[0] / 2.2 / np.diff(ax3.get_ylim())[0])
					ax3.set_aspect(asp)

					labels = [item.get_text() for item in ax3.get_yticklabels()]
					labels[:] = ""
					ax3.set_yticklabels(labels)

					ax3.legend(loc='upper left')
					ax3.grid()

					ax3.arrow(0, .85, np.max(abs(importances)) / 10, 0, length_includes_head=False, head_width=0.1, head_length=0.03, width=.05,color=(24/255,196/255,93/255))
					ax3.arrow(0, .85, -(np.max(abs(importances)) / 10), 0, length_includes_head=False,head_width=0.1, head_length=0.03,width=.05,color=(245/255,39/255,87/255))

					ax[0].set_title("Image")
					ax[1].set_title("Explanation")
					ax3.set_title("Feature importance uncertainty")

				if METHOD == "BAYESLIME":
					folder = "bayeslime"
				else:
					folder = "lime"

				if PERTURBATION_AMOUNT == 25:
					plt.savefig('./userstudy/uncertainty_vis_experiment/{}/low/{}.png'.format(folder,IMAGEID))
				else:
					plt.savefig('./userstudy/uncertainty_vis_experiment/{}/high/{}.png'.format(folder,IMAGEID))
				
				plt.clf()
				plt.close(fig)

def masking_user_study(run_args):

	data = "experiments/user-study-data.p"
	with open(data, "rb") as f:
			results = pkl.load(f)

	explanations_using_uncertainty = results['explanations_using_uncertainty']
	baseline_explanation = results['baseline_explanation']
	uncertainty_delta_class_probs = results['uncertainty_delta_class_probs']
	baseline_original_delta_class_probs = results['baseline_original_delta_class_probs']
	image_reference = results['image_reference']
	images = np.array(results['all_images']).reshape(-1,28,28)
	masks = np.array(results['all_masks']).reshape(-1,28,28)

	p_0 = np.array([exp['p_0'] for exp in explanations_using_uncertainty])
	fid = np.array([exp['prediction_score'] for exp in baseline_explanation])

	image_references_use = np.unique(image_reference)

	for RNK in range(image_references_use.shape[0]):

		IMGIDS_CUR = image_reference == image_references_use[RNK]

		all_images_of_reference = images[IMGIDS_CUR]

		MAXFID_ID = np.argmax(fid[IMGIDS_CUR])
		MAXP0_ID = np.argmax(p_0[IMGIDS_CUR])

		print ('--')
		print (MAXFID_ID)
		print (MAXP0_ID)

		exp_p0 = explanations_using_uncertainty[IMGIDS_CUR][MAXP0_ID]['model'].coef_
		exp_fid = baseline_explanation[IMGIDS_CUR][MAXFID_ID]['model'].coef_

		print (np.argsort(exp_p0)[-4:])
		print (np.argsort(exp_fid)[-4:])

		exp_p0_mask = masks[IMGIDS_CUR][MAXP0_ID]
		exp_fid_mask = masks[IMGIDS_CUR][MAXFID_ID]

		max_p0_img = images[IMGIDS_CUR][MAXP0_ID]
		max_fid_img = images[IMGIDS_CUR][MAXFID_ID]

		def mask(values, segmentation, image):
			out = deepcopy(image)
			
			for q in range(1,5):
				most_important = np.argsort(abs(values))[-1 * q]
				out[segmentation == most_important] = np.min(image)

			return out

		plt.imshow(max_p0_img, cmap="gray")
		plt.savefig('./results/user_study-masking/blime_original/{}.png'.format(RNK))
		plt.clf()

		plt.imshow(mask(exp_p0, exp_p0_mask, max_p0_img), cmap="gray")
		plt.savefig('./results/user_study-masking/blime_masked/{}.png'.format(RNK))
		plt.clf()

		plt.imshow(max_fid_img,cmap="gray")
		plt.savefig('./results/user_study-masking/lime_original/{}.png'.format(RNK))
		plt.clf()

		plt.imshow(mask(exp_fid, exp_fid_mask, max_fid_img), cmap="gray")
		plt.savefig('./results/user_study-masking/lime_masked/{}.png'.format(RNK))
		plt.clf()

if __name__ == "__main__":
	run_args = get_args()

	if run_args.exp_type == "RFS":
		remove_features_experiment_sweep(run_args)
	elif run_args.exp_type == "GENEXAMPLES":
		generate_samples(run_args)
	elif run_args.exp_type == "VARLOOP":
		remove_features_experiment_sweep(run_args,True)
	elif run_args.exp_type == "PUC":
		predictive_uncertainty_experiment(run_args)
	elif run_args.exp_type == "SAM":
		get_samples_at_uncertanties_experiment(run_args)
	elif run_args.exp_type == "EX":
		correctness_examples(run_args)
	elif run_args.exp_type == "ADV":
		adversarial_examples(run_args)
	elif run_args.exp_type == "VARCAL":
		variance_calibration(run_args)
	elif run_args.exp_type == "REP":
		generate_residual_error_plots(run_args)
	elif run_args.exp_type == "QWC":
		queries_vs_wall_clock_time(run_args)
	elif run_args.exp_type == "CCT":
		check_certainty_thresh(run_args)
	elif run_args.exp_type == "MASK":
		masking_user_study(run_args)
	else:
		raise NameError("Experiment type {} unknown!")
