# uncertainty sampling experiments

# Params
IMAGENETDIR=./image_data/french_bulldog
IMAGENETLABEL=245
IMAGENETNIMAGES=100
IMAGENETSEGS=20
IMAGENETPERURBS=4000
BATCHSIZE=10
MODEL=vgg16

echo Uncertainty sampling
echo ================================================== 

# IMAGENET VGG16 LIME
FIGNAME=VGG16LIME
python3 experiment_main.py --rerun --exp_type PUC --batch_size $BATCHSIZE --n_perturbations $IMAGENETPERURBS --figure_name $FIGNAME --image_base_dir $IMAGENETDIR --model $MODEL --n_segments $IMAGENETSEGS --label $IMAGENETLABEL --n_images $IMAGENETNIMAGES --output_file experiments/vgg16-lime-ACTIVE-new.p 
echo ================================================== 




