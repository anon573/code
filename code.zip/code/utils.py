import os

from PIL import Image
from torchvision import models, transforms

import numpy as np

import torch
from torchvision import models, transforms
from torch.autograd import Variable
import torch.nn.functional as F

from sklearn.linear_model import BayesianRidge
from sklearn.metrics import r2_score

from scipy.stats import invgamma
import json

from mnist import mnist

import time
import math

import pandas as pd

term = 1e-6
num = 1e-6

def normpdf(x, mean, sd):
    # pdf of normal
    var = float(sd)**2
    denom = (2*math.pi*var)**.5
    num = math.exp(-(float(x)-float(mean))**2/(2*var))
    return num/denom

def get_and_preprocess_german():
    """
    ----------
    params : Params
    Returns:
    ----------
    Pandas data frame X of processed data, np.ndarray y, and list of column names
    """
    PROTECTED_CLASS = 1
    UNPROTECTED_CLASS = 0
    POSITIVE_OUTCOME = 1
    NEGATIVE_OUTCOME = 0

    X = pd.read_csv("text_data/german_processed.csv")
    y = X["GoodCustomer"]

    X = X.drop(["GoodCustomer", "PurposeOfLoan"], axis=1)
    X['Gender'] = [1 if v == "Male" else 0 for v in X['Gender'].values]

    y = np.array([POSITIVE_OUTCOME if p == 1 else NEGATIVE_OUTCOME for p in y.values])

    cols = [c for c in X]

    return X, y, cols, [i for i in range(len(cols)) if cols[i] in ['Gender', 'ForeignWorker', 'Single', 'HasTelephone', 'CheckingAccountBalance_geq_0', 'CheckingAccountBalance_geq_200', 'SavingsAccountBalance_geq_100', 'SavingsAccountBalance_geq_500', 'MissedPayments', 'NoCurrentLoan', 'CriticalAccountOrLoansElsewhere', 'OtherLoansAtBank', 'OtherLoansAtStore', 'HasCoapplicant', 'HasGuarantor', 'OwnsHouse', 'RentsHouse', 'Unemployed', 'YearsAtCurrentJob_lt_1', 'YearsAtCurrentJob_geq_4', 'JobClassIsSkilled']]

def get_and_preprocess_compas_data():
    """Handle processing of COMPAS according to: https://github.com/propublica/compas-analysis
    
    Parameters
    ----------
    params : Params
    Returns
    ----------
    Pandas data frame X of processed data, np.ndarray y, and list of column names
    """
    PROTECTED_CLASS = 1
    UNPROTECTED_CLASS = 0
    POSITIVE_OUTCOME = 1
    NEGATIVE_OUTCOME = 0

    compas_df = pd.read_csv("text_data/compas-scores-two-years.csv", index_col=0)
    compas_df = compas_df.loc[(compas_df['days_b_screening_arrest'] <= 30) &
                              (compas_df['days_b_screening_arrest'] >= -30) &
                              (compas_df['is_recid'] != -1) &
                              (compas_df['c_charge_degree'] != "O") &
                              (compas_df['score_text'] != "NA")]

    compas_df['length_of_stay'] = (pd.to_datetime(compas_df['c_jail_out']) - pd.to_datetime(compas_df['c_jail_in'])).dt.days
    X = compas_df[['age', 'two_year_recid','c_charge_degree', 'race', 'sex', 'priors_count', 'length_of_stay']]

    # if person has high score give them the _negative_ model outcome
    y = compas_df['two_year_recid']
    sens = X.pop('race')
    X.pop('two_year_recid')
    

    # assign African-American as the protected class
    X = pd.get_dummies(X)
    sensitive_attr = np.array(pd.get_dummies(sens).pop('African-American'))
    X['race'] = sensitive_attr

    X.pop('sex_Male')

    # make sure everything is lining up
    assert all((sens == 'African-American') == (X['race'] == PROTECTED_CLASS))
    cols = [col for col in X]

    return X, y, cols, [i for i in range(len(cols)) if cols[i] in ['c_charge_degree_F', 'c_charge_degree_M', 'sex_Female', 'race']]

##
# Code for handling images
#

def get_preprocess_transform():
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                    std=[0.229, 0.224, 0.225])     
    transf = transforms.Compose([
        transforms.ToTensor(),
        normalize
    ])    

    return transf 

def get_preprocess_transform_mnist():
    transf = transforms.Compose([
        transforms.ToTensor()
        ])

    return transf

preprocess_transform = get_preprocess_transform()
preprocess_transform_mnist = get_preprocess_transform_mnist()

def batch_predict(images, model, rootdir, batch_size=10):
    if rootdir == "compas" or rootdir == "german":
        return model.predict_proba(images)

    model.eval()

    if rootdir != "mnist":
        batch = torch.stack(tuple(preprocess_transform(i) for i in images), dim=0)
    else:
        images = np.array(images)
        batch = torch.from_numpy(images).float()

    for i in range(0, len(images), batch_size):
        z = batch[i:i+batch_size]

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        # device = "cpu"
        model.to(device)
        z = z.to(device)

        z = z.float()

        logits = model(z)
        p = F.softmax(logits, dim=1)

        if i == 0:
            probs = p.detach().cpu().numpy()
        else:
            probs = np.vstack((probs, p.detach().cpu().numpy()))

    return np.array(probs)

def get_image(path):
    with open(os.path.abspath(path), 'rb') as f:
        with Image.open(f) as img:
            return img.convert('RGB') 

def get_pill_transf(): 
    transf = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.CenterCrop(224)
    ])    

    return transf  

def get_input_transform():
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                    std=[0.229, 0.224, 0.225])       
    transf = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        normalize
    ])    

    return transf

transf = get_input_transform()

def get_input_tensors(img):
    # unsqeeze converts single image to batch of 1
    return transf(img).unsqueeze(0) 

def get_model(run_args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # device = "cpu"
    if run_args.model == "vgg16":
        model = models.vgg16(pretrained=True)
        model.to(device)
        model.eval()
    elif run_args.model == "v3":
        model = models.inception_v3(pretrained=True)
        model.to(device)
        model.eval()
    elif run_args.model == "resnet":
        model = models.resnet18(pretrained=True)
        model.to(device)
        model.eval()
    elif run_args.model == "mnist": 
        p = mnist.Net()
        p.load_state_dict(torch.load("mnist/mnist_cnn.pt"))
        p.to(device)
        p.eval()
        model = p
    elif run_args.model == "structured":
        model = None
        device = None
    else:
        raise NameError("Model {} currently not specified.".format(run_args.model))

    return model, device

def get_imagenet_class_labels():
    idx2label, cls2label, cls2idx = [], {}, {}
    with open(os.path.abspath('./data/imagenet_class_index.json'), 'r') as read_file:
        class_idx = json.load(read_file)
        idx2label = [class_idx[str(k)][1] for k in range(len(class_idx))]
        cls2label = {class_idx[str(k)][0]: class_idx[str(k)][1] for k in range(len(class_idx))}
        cls2idx = {class_idx[str(k)][0]: k for k in range(len(class_idx))}

    return idx2label, cls2label, cls2idx
#
###

class BayesianLinearRegression:
    # Vanilla bayesian regression f
    def __init__(self, xtrain=None, ytrain=None, weights=None, optimize_predictive_uncertainty=False, shap=False):
        if xtrain is not None:
            self.fit(xtrain, ytrain, weights, optimize_predictive_uncertainty=optimize_predictive_uncertainty, shap=shap)

    def fit(self, xtrain, ytrain, sample_weight=None, optimize_predictive_uncertainty=False, shap=False):
        # Initialize and train Bayesian Regression model using weighted estimate

        # initialize weights
        self.weights = sample_weight
        self.j = xtrain.shape[0]
        self.shap = shap

        # Add sample weighting
        if sample_weight is not None:
            self.q_1 = np.eye(xtrain.shape[0]) * sample_weight
        else:
            self.q_1 = np.eye(xtrain.shape[0])

        # Add bias -- no bias with shap
        if not shap:
            xtrain = xtrain.transpose()
            xtrain = np.vstack((np.ones(xtrain.shape[1]), xtrain)).transpose()

        # the l2 regularization matrix
        self.p = np.eye(xtrain.shape[1])

        # Fit weights and covariance matrix, adding ridge regression 
        self.v_b = np.linalg.inv(np.matmul(xtrain.transpose(), np.matmul(self.q_1, xtrain)) + self.p) #+ (np.eye(xtrain.shape[1]) * 1e-30))

        # optimize for running predictive uncertainty, don't need to do these
        if not optimize_predictive_uncertainty:
            self.b_hat = np.matmul(np.matmul(self.v_b, xtrain.transpose()), np.matmul(self.q_1, ytrain))
            yxt = ytrain - np.matmul(xtrain, self.b_hat)
            
            # Make sure problem is not ill defined
            assert(xtrain.shape[0] > xtrain.shape[1])

            self.deg = xtrain.shape[0]
            self.d = xtrain.shape[1]

            self.s_2 = (1 / self.deg) * (np.matmul(np.matmul(yxt.transpose(), self.q_1), yxt) + np.matmul(np.matmul(self.b_hat.transpose(), self.p), self.b_hat))

            if self.shap:
                self.coef_ = self.b_hat
                self.intercept_ = None
            else:
                self.coef_ = self.b_hat[1:]
                self.intercept_ = self.b_hat[0]

            # store local score, remove bias
            if not self.shap:
                self.model_score = self.score(xtrain[:,1:],ytrain)
            else:
                self.model_score = self.score(xtrain, ytrain)

    def compute_number_more_needed_for_cert(self, desired_cert_level):
        # Number more needed for cert
        S = self.deg * self.s_2
        T = np.mean(self.weights)

        return 4* S / (self.deg * T * desired_cert_level)

    def predict(self, xtest, weights=None, only_var=False, relative=False):
        # predictive distribution
        q_1 = np.eye(xtest.shape[0])    

        if not self.shap:
            xtest = xtest.transpose()
            xtest = np.vstack((np.ones(xtest.shape[1]), xtest)).transpose()

        if not only_var:
            response = np.matmul(xtest, self.b_hat)

        mat = np.matmul(np.matmul(xtest, self.v_b), xtest.transpose())

        # if we only need to get relative variance, drop s_2 (can only be positive)
        if not relative:
            var = self.s_2 * (q_1 + mat)
        else:
            var = mat

        diag = np.diagonal(var)

        # only give var if requested
        if not only_var:
            return response, np.sqrt(diag)
        else:
            return None, np.sqrt(diag)

    def score(self, xtest, ytest, sample_weight=None):
        pred, var = self.predict(xtest)
        return r2_score(ytest, pred, sample_weight=self.weights)

    def draw_samples(self, n_samples, prior=True):
        samples, biases = [], []

        # add slight prior if requested
        if prior:
            sigma_2 = invgamma.rvs(self.deg/2, scale = (self.deg * ((term * num + self.deg * self.s_2) / (num + self.deg))) / 2, size=n_samples)
        else: 
            sigma_2 = invgamma.rvs(self.deg/2, scale = (self.deg * self.s_2) / 2, size=n_samples)

        for s2 in sigma_2:
            values = np.random.multivariate_normal(self.b_hat, self.v_b * s2)

            if self.shap:
                samples.append(values)
                biases.append("NA")
            else:
                samples.append(values[1:])
                biases.append(values[0])

        r = {'weights': np.array(samples), 'biases': np.array(biases)}
        return r

    def draw_weight_unc_samples(self, n_samples):
        samples = []
        sigma_2 = invgamma.rvs(self.deg / 2, scale = (self.deg * self.s_2) / 2, size=n_samples) #/ self.weights[np.random.choice(len(self.weights))]

        for s2 in sigma_2:
            s = np.random.normal(0, s2)
            samples.append(s)

        return np.array(samples)

    def get_marginal_feature_importance_vals(self, index):

        r = {
        'degrees_of_freedom': self.deg,
        'v_ii': self.v_b[index,index],
        's_2': self.s_2
        }

        return r

