We provide bash files to run the experiments included in the paper.  Please see the experiment bash files corresponding to each experiment we run.  The experiments are
- calibration-experiment.sh (the calibration experiments in the paper)
- masking-experiment.sh (the p(e=0) vs fidelity masking experiments)
- ptg-experiment.sh (the ptg estimation experiment)
- uncertainty-sampling-experiment.sh (the uncertainty-sampling experiment)


Note, in order to run the MNIST experiments, the MNIST model must be retrained.  This can be done through running mnist.py in the mnist directory.  Training is fairly rapid and takes only a couple minutes.
