# variance calibration exps
IMAGENETDIR=./image_data/french_bulldog
IMAGENETLABEL=245
IMAGENETNIMAGES=100
IMAGENETSEGS=20

MNISTDIR=mnist
MNISTLABEL=4
MNISTIMAGES=10
MNISTSEGS=20

COMPASDIR=compas
COMPASLABEL=0
COMPASINSTANCES=10

GERMANINSTANCES=10

echo Variance calibration experiments 
echo ================================================== 

# LIME
echo MNIST LIME 
python3 experiment_main.py --rerun --exp_type VARLOOP --image_base_dir $MNISTDIR --model $MNISTDIR --n_segments $MNISTSEGS --label $MNISTLABEL --n_images $MNISTIMAGES --output_file experiments/mnist-lime-VARCAL.p 
python3 experiment_main.py --exp_type VARCAL --output_file experiments/mnist-lime-VARCAL.p --label $MNISTLABEL 
echo --- 

echo COMPAS LIME
python3 experiment_main.py --rerun --explainer_type structured --exp_type VARLOOP --image_base_dir $COMPASDIR --model structured --label $COMPASLABEL --n_images $COMPASINSTANCES --output_file experiments/compas-lime-VARCAL.p 
python3 experiment_main.py --exp_type VARCAL --output_file experiments/compas-lime-VARCAL.p --label 0 
echo --- 

echo GERMAN LIME 
python3 experiment_main.py --rerun --explainer_type structured --exp_type VARLOOP --image_base_dir german --model structured --label $COMPASLABEL --n_images $GERMANINSTANCES --output_file experiments/german-lime-VARCAL.p 
python3 experiment_main.py --exp_type VARCAL --output_file experiments/german-lime-VARCAL.p --label 0 
echo --- 

# IMAGENET VGG16 LIME
echo VGG16 LIME 
python3 experiment_main.py --rerun --exp_type VARLOOP --image_base_dir $IMAGENETDIR --model vgg16 --n_segments $IMAGENETSEGS --label $IMAGENETLABEL --n_images $IMAGENETNIMAGES --output_file experiments/vgg16-lime-VARCAL.p 
python3 experiment_main.py --exp_type VARCAL --output_file experiments/vgg16-lime-VARCAL.p --label $IMAGENETLABEL 
echo --- 

# SHAP
echo MNIST SHAP 
python3 experiment_main.py --rerun --exp_type VARLOOP --image_base_dir $MNISTDIR --model $MNISTDIR --n_segments $MNISTSEGS --label $MNISTLABEL --n_images $MNISTIMAGES --output_file experiments/mnist-shap-VARCAL.p --shap 
python3 experiment_main.py --exp_type VARCAL --output_file experiments/mnist-shap-VARCAL.p --label $MNISTLABEL --shap 
echo --- 

echo COMPAS SHAP
python3 experiment_main.py --rerun --explainer_type structured --exp_type VARLOOP --image_base_dir $COMPASDIR --model structured --label $COMPASLABEL --n_images $COMPASINSTANCES --output_file experiments/german-shap-VARCAL.p --shap
python3 experiment_main.py --exp_type VARCAL --output_file experiments/german-lime-VARCAL.p --label 0 --model structured
echo --- 

echo GERMAN SHAP
python3 experiment_main.py --rerun --explainer_type structured --exp_type VARLOOP --image_base_dir german --model structured --label $COMPASLABEL --n_images $GERMANINSTANCES --output_file experiments/german-shap-VARCAL.p --shap
python3 experiment_main.py --exp_type VARCAL --output_file experiments/german-shap-VARCAL.p --label 0 --shap --model structured
echo --- 

# IMAGENET VGG16 LIME
echo VGG16 SHAP 
python3 experiment_main.py --rerun --exp_type VARLOOP --image_base_dir $IMAGENETDIR --model vgg16 --n_segments $IMAGENETSEGS --label $IMAGENETLABEL --n_images $IMAGENETNIMAGES --output_file experiments/vgg16-shap-VARCAL-new.p --shap 
python3 experiment_main.py --exp_type VARCAL --output_file experiments/vgg16-shap-VARCAL-new.p  --label $IMAGENETLABEL --shap 
echo --- 

echo ================================================== 




